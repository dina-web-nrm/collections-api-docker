-- MySQL dump 10.13  Distrib 5.6.21, for osx10.10 (x86_64)
--
-- Host: 192.168.99.100    Database: keycloak
-- ------------------------------------------------------
-- Server version	5.7.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `keycloak`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `keycloak` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `keycloak`;

--
-- Table structure for table `ADMIN_EVENT_ENTITY`
--

DROP TABLE IF EXISTS `ADMIN_EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ADMIN_EVENT_ENTITY` (
  `ID` varchar(36) NOT NULL,
  `ADMIN_EVENT_TIME` bigint(20) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `OPERATION_TYPE` varchar(255) DEFAULT NULL,
  `AUTH_REALM_ID` varchar(255) DEFAULT NULL,
  `AUTH_CLIENT_ID` varchar(255) DEFAULT NULL,
  `AUTH_USER_ID` varchar(255) DEFAULT NULL,
  `IP_ADDRESS` varchar(255) DEFAULT NULL,
  `RESOURCE_PATH` varchar(2550) DEFAULT NULL,
  `REPRESENTATION` text,
  `ERROR` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADMIN_EVENT_ENTITY`
--

LOCK TABLES `ADMIN_EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_EXECUTION`
--

DROP TABLE IF EXISTS `AUTHENTICATION_EXECUTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTHENTICATION_EXECUTION` (
  `ID` varchar(36) NOT NULL,
  `ALIAS` varchar(255) DEFAULT NULL,
  `AUTHENTICATOR` varchar(36) DEFAULT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  `FLOW_ID` varchar(36) DEFAULT NULL,
  `REQUIREMENT` int(11) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `AUTHENTICATOR_FLOW` bit(1) NOT NULL DEFAULT b'0',
  `AUTH_FLOW_ID` varchar(36) DEFAULT NULL,
  `AUTH_CONFIG` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_AUTH_EXEC_REALM` (`REALM_ID`),
  KEY `FK_AUTH_EXEC_FLOW` (`FLOW_ID`),
  CONSTRAINT `FK_AUTH_EXEC_FLOW` FOREIGN KEY (`FLOW_ID`) REFERENCES `AUTHENTICATION_FLOW` (`ID`),
  CONSTRAINT `FK_AUTH_EXEC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_EXECUTION`
--

LOCK TABLES `AUTHENTICATION_EXECUTION` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('01400e57-5457-4508-b9b3-04a6ad70d127',NULL,'auth-spnego','dina','83da829e-be7f-4469-8558-1fc768c03f52',3,20,'\0',NULL,NULL),('1685513f-758e-4abe-ad80-080da6e2ed8d',NULL,'direct-grant-validate-otp','dina','94927455-1bba-4e1e-a195-444b092f8f29',1,30,'\0',NULL,NULL),('1805238c-949c-435b-8138-ebf9258b95f1',NULL,'auth-cookie','master','40a64c43-f7d5-4fe7-a548-4fc153cab40b',2,10,'\0',NULL,NULL),('1cb269d5-0a50-40f2-9c9c-1a4942fc37a3',NULL,'auth-username-password-form','dina','c02542dd-0070-4f71-8ac2-1caeb11da1f1',0,10,'\0',NULL,NULL),('1f4bd715-53a9-4e0e-a2f1-97f9c0655199',NULL,'registration-recaptcha-action','dina','80c02504-e10a-4d50-a346-1d9e4edbb9e5',3,60,'\0',NULL,NULL),('33d1ff6e-7a17-42fe-b3d7-5bf4a9b75f0a',NULL,'direct-grant-validate-password','dina','94927455-1bba-4e1e-a195-444b092f8f29',0,20,'\0',NULL,NULL),('35d92382-9d4f-47fe-b1a3-3f99022bede0',NULL,NULL,'dina','83da829e-be7f-4469-8558-1fc768c03f52',2,30,'','c02542dd-0070-4f71-8ac2-1caeb11da1f1',NULL),('36824255-5781-4387-9e69-4e74400dd3d0',NULL,'registration-password-action','master','fef37006-aa50-471b-9b99-d48926a9c3bd',0,50,'\0',NULL,NULL),('3b5fc4b1-d243-4637-8b00-d65897628589',NULL,'auth-username-password-form','master','4a92b0f6-a4c9-4a50-8a3e-e59648422b49',0,10,'\0',NULL,NULL),('45d88407-7f58-4667-a06c-da65ced7400c',NULL,'auth-cookie','dina','83da829e-be7f-4469-8558-1fc768c03f52',2,10,'\0',NULL,NULL),('48fc47ed-c15f-45d8-b870-31d97da854fa',NULL,'client-secret','dina','7d5b79be-4c68-4b74-bc46-e819a952cb6b',2,10,'\0',NULL,NULL),('4ee1ed9d-ec0c-4625-8a6a-61bab020563c',NULL,'reset-credential-email','dina','f35341b4-10e2-4fbd-a303-580c1455cdc9',0,20,'\0',NULL,NULL),('50e65f75-d609-432c-9b51-8f6af990f4b4',NULL,'registration-recaptcha-action','master','fef37006-aa50-471b-9b99-d48926a9c3bd',3,60,'\0',NULL,NULL),('5324c7f8-84ab-4183-ae08-b118992b001f',NULL,'auth-spnego','master','40a64c43-f7d5-4fe7-a548-4fc153cab40b',3,20,'\0',NULL,NULL),('53ccf7b6-274f-4cb0-8caf-125340cfad60',NULL,NULL,'master','40a64c43-f7d5-4fe7-a548-4fc153cab40b',2,30,'','4a92b0f6-a4c9-4a50-8a3e-e59648422b49',NULL),('56051e54-6a3a-4fb2-bdf1-5ec0487ed10e',NULL,'registration-password-action','dina','80c02504-e10a-4d50-a346-1d9e4edbb9e5',0,50,'\0',NULL,NULL),('5c376f49-88f4-4a20-b840-f74bf5b208c4',NULL,'direct-grant-validate-otp','master','f11d1afb-3632-4f97-a94a-35e7a465738f',1,30,'\0',NULL,NULL),('656530a7-c9d5-494a-b1a5-11f923775ceb',NULL,'client-jwt','master','45f48310-0eae-4b74-8584-f901694c3671',2,20,'\0',NULL,NULL),('6a70ccd3-33fe-4ae5-9633-635e4a47a44c',NULL,'registration-user-creation','master','fef37006-aa50-471b-9b99-d48926a9c3bd',0,20,'\0',NULL,NULL),('7fa5436d-61d1-4cad-b3a9-536f8fb50ca7',NULL,'direct-grant-validate-username','dina','94927455-1bba-4e1e-a195-444b092f8f29',0,10,'\0',NULL,NULL),('888d3900-f9bf-4f50-a82c-64b2a0d15952',NULL,'reset-otp','dina','f35341b4-10e2-4fbd-a303-580c1455cdc9',1,40,'\0',NULL,NULL),('93f5ba7a-614d-4166-a3c7-80964b417d29',NULL,'reset-credentials-choose-user','master','84f3af3e-f58d-4e9e-b690-3037d4affbd4',0,10,'\0',NULL,NULL),('94d0f61a-fcd7-4c97-9467-47e95d58ccfc',NULL,'registration-profile-action','dina','80c02504-e10a-4d50-a346-1d9e4edbb9e5',0,40,'\0',NULL,NULL),('97c0016c-cf4e-4662-97ab-117848ddd086',NULL,'reset-credential-email','master','84f3af3e-f58d-4e9e-b690-3037d4affbd4',0,20,'\0',NULL,NULL),('9c3cd132-b2b5-446c-b430-89a32c1b8fa5',NULL,'registration-page-form','master','c1ed2be4-bbae-4148-9d5c-61def97c3d78',0,10,'','fef37006-aa50-471b-9b99-d48926a9c3bd',NULL),('beb17a10-111f-4422-808f-86d51a098c00',NULL,'direct-grant-validate-username','master','f11d1afb-3632-4f97-a94a-35e7a465738f',0,10,'\0',NULL,NULL),('bf888982-6f0a-46f9-950f-ae64e340578f',NULL,'registration-user-creation','dina','80c02504-e10a-4d50-a346-1d9e4edbb9e5',0,20,'\0',NULL,NULL),('c2034673-74f8-422f-8148-243234d4eaef',NULL,'reset-otp','master','84f3af3e-f58d-4e9e-b690-3037d4affbd4',1,40,'\0',NULL,NULL),('c6a8495c-a1e7-4d19-9aad-08dab62c7532',NULL,'registration-profile-action','master','fef37006-aa50-471b-9b99-d48926a9c3bd',0,40,'\0',NULL,NULL),('cd9267ae-c0b8-45b0-afee-5f4af0c3fd7a',NULL,'auth-otp-form','dina','c02542dd-0070-4f71-8ac2-1caeb11da1f1',1,20,'\0',NULL,NULL),('d142aff6-ace5-40a2-bc74-901315597142',NULL,'reset-password','dina','f35341b4-10e2-4fbd-a303-580c1455cdc9',0,30,'\0',NULL,NULL),('dc47d83c-6f64-4a86-bc5d-1e85d3583c44',NULL,'auth-otp-form','master','4a92b0f6-a4c9-4a50-8a3e-e59648422b49',1,20,'\0',NULL,NULL),('e5478c25-6431-480e-a248-4d8c624d8e32',NULL,'client-jwt','dina','7d5b79be-4c68-4b74-bc46-e819a952cb6b',2,20,'\0',NULL,NULL),('ee614bc6-10c5-4dee-aef9-af55cac8284f',NULL,'reset-password','master','84f3af3e-f58d-4e9e-b690-3037d4affbd4',0,30,'\0',NULL,NULL),('f046cd55-edfb-4fa2-8666-f53af5ff9968',NULL,'reset-credentials-choose-user','dina','f35341b4-10e2-4fbd-a303-580c1455cdc9',0,10,'\0',NULL,NULL),('f3e3a42d-2df3-491e-b2e9-12ab6f60957e',NULL,'client-secret','master','45f48310-0eae-4b74-8584-f901694c3671',2,10,'\0',NULL,NULL),('f59e34bf-83a4-4036-aff4-81789d9e8f4a',NULL,'direct-grant-validate-password','master','f11d1afb-3632-4f97-a94a-35e7a465738f',0,20,'\0',NULL,NULL),('f9a6d5ab-02a5-48e4-bb85-662dbd70da1a',NULL,'registration-page-form','dina','232581d1-102f-4720-8be9-1140c692ed06',0,10,'','80c02504-e10a-4d50-a346-1d9e4edbb9e5',NULL);
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_FLOW`
--

DROP TABLE IF EXISTS `AUTHENTICATION_FLOW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTHENTICATION_FLOW` (
  `ID` varchar(36) NOT NULL,
  `ALIAS` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  `PROVIDER_ID` varchar(36) NOT NULL DEFAULT 'basic-flow',
  `TOP_LEVEL` bit(1) NOT NULL DEFAULT b'0',
  `BUILT_IN` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  KEY `FK_AUTH_FLOW_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_FLOW_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_FLOW`
--

LOCK TABLES `AUTHENTICATION_FLOW` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('232581d1-102f-4720-8be9-1140c692ed06','registration','registration flow','dina','basic-flow','',''),('40a64c43-f7d5-4fe7-a548-4fc153cab40b','browser','browser based authentication','master','basic-flow','',''),('45f48310-0eae-4b74-8584-f901694c3671','clients','Base authentication for clients','master','client-flow','',''),('4a92b0f6-a4c9-4a50-8a3e-e59648422b49','forms','Username, password, otp and other auth forms.','master','basic-flow','\0',''),('7d5b79be-4c68-4b74-bc46-e819a952cb6b','clients','Base authentication for clients','dina','client-flow','',''),('80c02504-e10a-4d50-a346-1d9e4edbb9e5','registration form','registration form','dina','form-flow','\0',''),('83da829e-be7f-4469-8558-1fc768c03f52','browser','browser based authentication','dina','basic-flow','',''),('84f3af3e-f58d-4e9e-b690-3037d4affbd4','reset credentials','Reset credentials for a user if they forgot their password or something','master','basic-flow','',''),('94927455-1bba-4e1e-a195-444b092f8f29','direct grant','OpenID Connect Resource Owner Grant','dina','basic-flow','',''),('c02542dd-0070-4f71-8ac2-1caeb11da1f1','forms','Username, password, otp and other auth forms.','dina','basic-flow','\0',''),('c1ed2be4-bbae-4148-9d5c-61def97c3d78','registration','registration flow','master','basic-flow','',''),('f11d1afb-3632-4f97-a94a-35e7a465738f','direct grant','OpenID Connect Resource Owner Grant','master','basic-flow','',''),('f35341b4-10e2-4fbd-a303-580c1455cdc9','reset credentials','Reset credentials for a user if they forgot their password or something','dina','basic-flow','',''),('fef37006-aa50-471b-9b99-d48926a9c3bd','registration form','registration form','master','form-flow','\0','');
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTHENTICATOR_CONFIG` (
  `ID` varchar(36) NOT NULL,
  `ALIAS` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_AUTH_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG`
--

LOCK TABLES `AUTHENTICATOR_CONFIG` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG_ENTRY`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG_ENTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUTHENTICATOR_CONFIG_ENTRY` (
  `AUTHENTICATOR_ID` varchar(36) NOT NULL,
  `VALUE` longtext,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`AUTHENTICATOR_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG_ENTRY`
--

LOCK TABLES `AUTHENTICATOR_CONFIG_ENTRY` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT` (
  `ID` varchar(36) NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FULL_SCOPE_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_ID` varchar(255) DEFAULT NULL,
  `NOT_BEFORE` int(11) DEFAULT NULL,
  `PUBLIC_CLIENT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` varchar(255) DEFAULT NULL,
  `BASE_URL` varchar(255) DEFAULT NULL,
  `BEARER_ONLY` bit(1) NOT NULL DEFAULT b'0',
  `MANAGEMENT_URL` varchar(255) DEFAULT NULL,
  `SURROGATE_AUTH_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `DIRECT_GRANTS_ONLY` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) DEFAULT NULL,
  `PROTOCOL` varchar(255) DEFAULT NULL,
  `NODE_REREG_TIMEOUT` int(11) DEFAULT '0',
  `FRONTCHANNEL_LOGOUT` bit(1) NOT NULL DEFAULT b'0',
  `CONSENT_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `NAME` varchar(255) DEFAULT NULL,
  `SERVICE_ACCOUNTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_AUTHENTICATOR_TYPE` varchar(255) DEFAULT NULL,
  `ROOT_URL` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_B71CJLBENV945RB6GCON438AT` (`REALM_ID`,`CLIENT_ID`),
  CONSTRAINT `FK_P56CTINXXB9GSK57FO49F9TAC` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES ('12a00924-5501-4a34-a368-2be92698759c','','\0','account',0,'\0','20f99383-ce3f-4d1c-9713-ace8c5fd5855','/auth/realms/dina/account','\0',NULL,'\0','\0','dina',NULL,0,'\0','\0','${client_account}','\0','client-secret',NULL,NULL),('2d57c124-63e6-4f07-977c-79167ff268f8','','','test-client',0,'\0','c1bf8b42-608f-4ab2-b9bb-9b82001f96ac',NULL,'\0',NULL,'\0','\0','dina','openid-connect',-1,'\0','\0','test-client','\0','client-secret',NULL,'dina rest client'),('370b6760-428e-4b14-850b-a9bfd25fcd8c','','','dina-realm',0,'\0','110efea6-d837-48e8-8c83-8dbf685f2ae5',NULL,'',NULL,'\0','\0','master',NULL,0,'\0','\0','dina Realm','\0','client-secret',NULL,NULL),('4f8273ca-19e1-47f8-acbf-ed2359a6ada0','','\0','broker',0,'\0','015b3872-dfc4-458f-983f-29993ff75229',NULL,'\0',NULL,'\0','\0','master',NULL,0,'\0','\0','${client_broker}','\0','client-secret',NULL,NULL),('5040b99e-aabf-4164-8780-0fc67c193318','','','test-client-local',0,'\0','4889a7ef-5d47-4c96-8ae4-e29bc4469e25',NULL,'\0',NULL,'\0','\0','dina','openid-connect',-1,'\0','\0','test-client-local','\0','client-secret',NULL,NULL),('b0276453-5047-40e9-a07d-d3da942fb21e','','\0','security-admin-console',0,'','0608caed-787d-469c-9730-17a05b8b886c','/auth/admin/master/console/index.html','\0',NULL,'\0','\0','master',NULL,0,'\0','\0','${client_security-admin-console}','\0','client-secret',NULL,NULL),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','','','dina-rest-endpoint',0,'','5b423ad5-d300-466b-a1b9-ff9dbcdebb52',NULL,'\0',NULL,'\0','','dina','openid-connect',-1,'\0','\0','dina-rest-endpoint','\0','client-secret',NULL,NULL),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','','','dina-service',0,'\0','d8a90a90-7309-4acb-a9c9-cc4675c943fa',NULL,'',NULL,'\0','\0','dina','openid-connect',-1,'\0','\0','dina-service','\0','client-secret',NULL,'dina rest api'),('cd875af9-7482-4bcc-a875-32d45029742f','','\0','security-admin-console',0,'','0791808c-414a-4e6f-a032-2004bbd6c798','/auth/admin/dina/console/index.html','\0',NULL,'\0','\0','dina',NULL,0,'\0','\0','${client_security-admin-console}','\0','client-secret',NULL,NULL),('dc20d618-412c-4502-93d6-e4e90d0f3e70','','','master-realm',0,'\0','fd0f3098-f0ed-4f19-8b7d-f0d106c4ca3b',NULL,'',NULL,'\0','\0','master',NULL,0,'\0','\0','master Realm','\0','client-secret',NULL,NULL),('eb90332f-156d-4cec-8952-857232b91b3d','','\0','realm-management',0,'\0','7b7bac5a-5748-4c5e-861e-7a20bf7bb530',NULL,'',NULL,'\0','\0','dina',NULL,0,'\0','\0','${client_realm-management}','\0','client-secret',NULL,NULL),('f7b7fe46-ec29-4f68-95be-fbf3d55afc01','','\0','account',0,'\0','44e8f8c7-2e5e-4532-9ae8-edb9be5a2e25','/auth/realms/master/account','\0',NULL,'\0','\0','master',NULL,0,'\0','\0','${client_account}','\0','client-secret',NULL,NULL),('fe2e52fe-e34f-439e-bc4f-b1f48a1431b4','','\0','broker',0,'\0','2a362b81-b916-4bd9-b9fc-1287ad495c87',NULL,'\0',NULL,'\0','\0','dina',NULL,0,'\0','\0','${client_broker}','\0','client-secret',NULL,NULL);
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_ATTRIBUTES`
--

DROP TABLE IF EXISTS `CLIENT_ATTRIBUTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_ATTRIBUTES` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `VALUE` varchar(2048) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  CONSTRAINT `FK3C47C64BEACCA966` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_ATTRIBUTES`
--

LOCK TABLES `CLIENT_ATTRIBUTES` WRITE;
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` DISABLE KEYS */;
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.assertion.signature'),('2d57c124-63e6-4f07-977c-79167ff268f8','true','saml.authnstatement'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.client.signature'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.encrypt'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.force.post.binding'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.multivalued.roles'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml.server.signature'),('2d57c124-63e6-4f07-977c-79167ff268f8','RSA_SHA256','saml.signature.algorithm'),('2d57c124-63e6-4f07-977c-79167ff268f8','false','saml_force_name_id_format'),('2d57c124-63e6-4f07-977c-79167ff268f8','username','saml_name_id_format'),('2d57c124-63e6-4f07-977c-79167ff268f8','http://www.w3.org/2001/10/xml-exc-c14n#','saml_signature_canonicalization_method'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.assertion.signature'),('5040b99e-aabf-4164-8780-0fc67c193318','true','saml.authnstatement'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.client.signature'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.encrypt'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.force.post.binding'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.multivalued.roles'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml.server.signature'),('5040b99e-aabf-4164-8780-0fc67c193318','RSA_SHA256','saml.signature.algorithm'),('5040b99e-aabf-4164-8780-0fc67c193318','false','saml_force_name_id_format'),('5040b99e-aabf-4164-8780-0fc67c193318','username','saml_name_id_format'),('5040b99e-aabf-4164-8780-0fc67c193318','http://www.w3.org/2001/10/xml-exc-c14n#','saml_signature_canonicalization_method'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.assertion.signature'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','true','saml.authnstatement'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.client.signature'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.encrypt'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.force.post.binding'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.multivalued.roles'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml.server.signature'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','RSA_SHA256','saml.signature.algorithm'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','false','saml_force_name_id_format'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','username','saml_name_id_format'),('bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','http://www.w3.org/2001/10/xml-exc-c14n#','saml_signature_canonicalization_method'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.assertion.signature'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','true','saml.authnstatement'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.client.signature'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.encrypt'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.force.post.binding'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.multivalued.roles'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml.server.signature'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','RSA_SHA256','saml.signature.algorithm'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','false','saml_force_name_id_format'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','username','saml_name_id_format'),('c72b4202-09f9-4f37-a4ca-62b3e91bcab7','http://www.w3.org/2001/10/xml-exc-c14n#','saml_signature_canonicalization_method');
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_DEFAULT_ROLES`
--

DROP TABLE IF EXISTS `CLIENT_DEFAULT_ROLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_DEFAULT_ROLES` (
  `CLIENT_ID` varchar(36) DEFAULT NULL,
  `ROLE_ID` varchar(36) NOT NULL,
  UNIQUE KEY `UK_8AELWNIBJI49AVXSRTUF6XJOW` (`ROLE_ID`),
  KEY `FK_NUILTS7KLWQW2H8M2B5JOYTKY` (`CLIENT_ID`),
  CONSTRAINT `FK_8AELWNIBJI49AVXSRTUF6XJOW` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`),
  CONSTRAINT `FK_NUILTS7KLWQW2H8M2B5JOYTKY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_DEFAULT_ROLES`
--

LOCK TABLES `CLIENT_DEFAULT_ROLES` WRITE;
/*!40000 ALTER TABLE `CLIENT_DEFAULT_ROLES` DISABLE KEYS */;
INSERT INTO `CLIENT_DEFAULT_ROLES` VALUES ('12a00924-5501-4a34-a368-2be92698759c','89ffb599-3910-4588-b155-8e8518682175'),('12a00924-5501-4a34-a368-2be92698759c','99b83880-32ee-4ffe-827c-0bfdd9acb303'),('f7b7fe46-ec29-4f68-95be-fbf3d55afc01','b9640b04-5396-439f-8e4b-7bffff950f59'),('f7b7fe46-ec29-4f68-95be-fbf3d55afc01','d8eec9a7-a05d-48d9-93ef-a82293979dec');
/*!40000 ALTER TABLE `CLIENT_DEFAULT_ROLES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_IDENTITY_PROV_MAPPING`
--

DROP TABLE IF EXISTS `CLIENT_IDENTITY_PROV_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_IDENTITY_PROV_MAPPING` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `IDENTITY_PROVIDER_ID` varchar(36) NOT NULL,
  `RETRIEVE_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  UNIQUE KEY `UK_7CAELWNIBJI49AVXSRTUF6XJ12` (`IDENTITY_PROVIDER_ID`,`CLIENT_ID`),
  KEY `FK_56ELWNIBJI49AVXSRTUF6XJ23` (`CLIENT_ID`),
  CONSTRAINT `FK_56ELWNIBJI49AVXSRTUF6XJ23` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`),
  CONSTRAINT `FK_7CELWNIBJI49AVXSRTUF6XJ12` FOREIGN KEY (`IDENTITY_PROVIDER_ID`) REFERENCES `IDENTITY_PROVIDER` (`INTERNAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_IDENTITY_PROV_MAPPING`
--

LOCK TABLES `CLIENT_IDENTITY_PROV_MAPPING` WRITE;
/*!40000 ALTER TABLE `CLIENT_IDENTITY_PROV_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_IDENTITY_PROV_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_NODE_REGISTRATIONS`
--

DROP TABLE IF EXISTS `CLIENT_NODE_REGISTRATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_NODE_REGISTRATIONS` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `VALUE` int(11) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  CONSTRAINT `FK4129723BA992F594` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_NODE_REGISTRATIONS`
--

LOCK TABLES `CLIENT_NODE_REGISTRATIONS` WRITE;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION`
--

DROP TABLE IF EXISTS `CLIENT_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_SESSION` (
  `ID` varchar(36) NOT NULL,
  `CLIENT_ID` varchar(36) DEFAULT NULL,
  `REDIRECT_URI` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `TIMESTAMP` int(11) DEFAULT NULL,
  `SESSION_ID` varchar(36) DEFAULT NULL,
  `AUTH_METHOD` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `AUTH_USER_ID` varchar(36) DEFAULT NULL,
  `CURRENT_ACTION` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_B4AO2VCVAT6UKAU74WBWTFQO1` (`SESSION_ID`),
  CONSTRAINT `FK_B4AO2VCVAT6UKAU74WBWTFQO1` FOREIGN KEY (`SESSION_ID`) REFERENCES `USER_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION`
--

LOCK TABLES `CLIENT_SESSION` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_AUTH_STATUS`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_AUTH_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_SESSION_AUTH_STATUS` (
  `AUTHENTICATOR` varchar(36) NOT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`AUTHENTICATOR`),
  CONSTRAINT `AUTH_STATUS_CONSTRAINT` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_AUTH_STATUS`
--

LOCK TABLES `CLIENT_SESSION_AUTH_STATUS` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_AUTH_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_AUTH_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_NOTE`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_SESSION_NOTE` (
  `NAME` varchar(255) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`NAME`),
  CONSTRAINT `FK5EDFB00FF51C2736` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_NOTE`
--

LOCK TABLES `CLIENT_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_PROT_MAPPER`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_PROT_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_SESSION_PROT_MAPPER` (
  `PROTOCOL_MAPPER_ID` varchar(36) NOT NULL,
  `CLIENT_SESSION` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`PROTOCOL_MAPPER_ID`),
  CONSTRAINT `FK_33A8SGQW18I532811V7O2DK89` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_PROT_MAPPER`
--

LOCK TABLES `CLIENT_SESSION_PROT_MAPPER` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_PROT_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_PROT_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_ROLE`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_SESSION_ROLE` (
  `ROLE_ID` varchar(255) NOT NULL,
  `CLIENT_SESSION` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`ROLE_ID`),
  CONSTRAINT `FK_11B7SGQW18I532811V7O2DV76` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_ROLE`
--

LOCK TABLES `CLIENT_SESSION_ROLE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_ROLE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_USER_SESSION_NOTE`
--

DROP TABLE IF EXISTS `CLIENT_USER_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_USER_SESSION_NOTE` (
  `NAME` varchar(255) NOT NULL,
  `VALUE` varchar(2048) DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`NAME`),
  CONSTRAINT `FK_CL_USR_SES_NOTE` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_USER_SESSION_NOTE`
--

LOCK TABLES `CLIENT_USER_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `CLIENT_USER_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_USER_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPOSITE_ROLE`
--

DROP TABLE IF EXISTS `COMPOSITE_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMPOSITE_ROLE` (
  `COMPOSITE` varchar(36) NOT NULL,
  `CHILD_ROLE` varchar(36) NOT NULL,
  KEY `FK_A63WVEKFTU8JO1PNJ81E7MCE2` (`COMPOSITE`),
  KEY `FK_GR7THLLB9LU8Q4VQA4524JJY8` (`CHILD_ROLE`),
  CONSTRAINT `FK_A63WVEKFTU8JO1PNJ81E7MCE2` FOREIGN KEY (`COMPOSITE`) REFERENCES `KEYCLOAK_ROLE` (`ID`),
  CONSTRAINT `FK_GR7THLLB9LU8Q4VQA4524JJY8` FOREIGN KEY (`CHILD_ROLE`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPOSITE_ROLE`
--

LOCK TABLES `COMPOSITE_ROLE` WRITE;
/*!40000 ALTER TABLE `COMPOSITE_ROLE` DISABLE KEYS */;
INSERT INTO `COMPOSITE_ROLE` VALUES ('f8a5df60-e37e-42ed-b538-c8be4192cc21','58750b48-fde2-405d-9c75-d412c6888841'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','00f7173b-9ce5-41e6-9e10-bdeb44a10b71'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','3788ee74-5d1c-4d95-97a1-2b719c576621'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','df01c91b-2d5f-4a9c-bcb2-c73607eb6cfe'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','0f3702a1-7b7f-481d-bca0-87107a3b9892'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','28ee72d6-db09-498a-a12f-5270baee8ac7'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','2a890a5a-caa8-40e1-adac-324a82da1db4'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','a9646aae-c487-4429-befd-9172700fc452'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','ed101cd9-aecc-4fb3-9fdc-75ae13c079aa'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','8f59422c-4890-4379-bc66-ac02cd406613'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','5488bc80-23cd-4e32-9b74-10e844df3ae6'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','ef1ec7c6-cab0-4d2f-a09c-c290cd97da97'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','5e8d8ed7-7855-4c37-b164-dfd946800137'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','681b2094-847f-4a86-85c7-19e41dbb9018'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','5f3e5f0f-e934-478c-a27e-beedf986eb87'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','e9e6b449-24c7-4f5e-905e-487ee260d676'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','7e9c4920-fa7c-486f-ae70-d38c82fd13ea'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','a4197d73-cbde-4d8d-bd4e-82fe1e5bc9d9'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','e1964767-7883-465b-8f69-9e853a698aac'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','c7005553-f54d-4885-b2c7-7f74feb65210'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','aca41b88-1dbe-42af-8cbd-dae75a508d22'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','5f4ba0d4-ff2c-42c4-bb9a-245dc53caef5'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','5e4a85a2-f2ee-44a7-9bac-8c1c06696562'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','1a3dcf36-1554-4a14-b78d-ca52c64e8466'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','7449b873-c42b-4081-b4e8-3480972417da'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','f31cfa8c-50ae-4048-bebf-e79c12d6e14f'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','dd967270-5122-4f32-af94-698dd3fda606'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','3fc85fdd-9bbd-4fef-bb0c-b77074fce0f9'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','23f7a6df-098b-4c48-8e47-83236b2cdea1'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','109ee28a-b5cb-4d56-80f7-86a985a98356'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','78ecfd66-d7d6-4be2-aaec-6ea702cf3161'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','dee3af16-4f7c-437d-b1b8-ca0c3d841695'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','56005e3b-9399-427c-b40a-28078fa8a0f8'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','7f422e78-651b-40e6-81a9-d7e8b0cc27cc'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','0a6eca76-3d2c-499e-90a8-47e8e2519a01'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','14204586-f6d4-4638-ba6c-a7b0b53b6ae1'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','a43b78d0-c1d1-46ec-b88c-cdda858bb987');
/*!40000 ALTER TABLE `COMPOSITE_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CREDENTIAL`
--

DROP TABLE IF EXISTS `CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CREDENTIAL` (
  `ID` varchar(36) NOT NULL,
  `DEVICE` varchar(255) DEFAULT NULL,
  `HASH_ITERATIONS` int(11) DEFAULT NULL,
  `SALT` blob,
  `TYPE` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` varchar(36) DEFAULT NULL,
  `CREATED_DATE` bigint(20) DEFAULT NULL,
  `COUNTER` int(11) DEFAULT '0',
  `DIGITS` int(11) DEFAULT '6',
  `PERIOD` int(11) DEFAULT '30',
  `ALGORITHM` varchar(36) DEFAULT 'HmacSHA1',
  PRIMARY KEY (`ID`),
  KEY `FK_PFYR0GLASQYL0DEI3KL69R6V0` (`USER_ID`),
  CONSTRAINT `FK_PFYR0GLASQYL0DEI3KL69R6V0` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CREDENTIAL`
--

LOCK TABLES `CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `CREDENTIAL` DISABLE KEYS */;
INSERT INTO `CREDENTIAL` VALUES ('0bce50c0-5184-436a-ba41-f740d496224b',NULL,1,'8Ngp�9\'����(i�h(','password','X8lG5ryksZP3DeXLkgxUjkQ6XkKp3U77h/c8ksjHpLwpKojbRkUM2V+vSU8aaGJlRRnHueV9ivcSTz+N4gMuUA==','fb600f3d-8a1d-4368-8fe1-239f56af7788',1448897237000,0,0,0,NULL),('6e236218-e3d8-4472-8694-3af52c860518',NULL,1,'����wEmP�p$#�0','password','/sc0qU4P0CgbWlnNjbzwfTDu31ajipyCY92E6Nw2YsY06Wd/azvllIabm5WpJwG+U1MZH7w9tYW57P8qd/bdCQ==','ad958216-4d3e-4f50-9edd-c9c6b0640adf',1448885337000,0,0,0,NULL),('937ccfbd-15de-43ef-b231-096aeb86240a',NULL,1,'���z�)<�$�8��p��','password','B3Vf5iseiOQczXX7xpHdZ8OlQ9FNLvx5z3dyY6h5gLRf9ERgf/FlGKyPY0AJqAQ8i62FwHSduh/MrIHEwmvyWg==','50b55ef3-6264-4cc5-8a2f-6736337a04ce',1448549452000,0,0,0,NULL);
/*!40000 ALTER TABLE `CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES ('1.0.0.Final','sthorger@redhat.com','META-INF/jpa-changelog-1.0.0.Final.xml','2015-11-24 14:45:27',1,'EXECUTED','7:00a57f7a6fb456639b34e62972e0ec02','createTable (x29), addPrimaryKey (x21), addUniqueConstraint (x9), addForeignKeyConstraint (x32)','',NULL,'3.4.1',NULL,NULL),('1.1.0.Beta1','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Beta1.xml','2015-11-24 14:45:27',2,'EXECUTED','7:0310eb8ba07cec616460794d42ade0fa','delete (x3), createTable (x3), addColumn (x5), addPrimaryKey (x3), addForeignKeyConstraint (x3), customChange','',NULL,'3.4.1',NULL,NULL),('1.1.0.Final','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Final.xml','2015-11-24 14:45:27',3,'EXECUTED','7:5d25857e708c3233ef4439df1f93f012','renameColumn','',NULL,'3.4.1',NULL,NULL),('1.2.0.Beta1','psilva@redhat.com','META-INF/jpa-changelog-1.2.0.Beta1.xml','2015-11-24 14:45:28',4,'EXECUTED','7:c7a54a1041d58eb3817a4a883b4d4e84','delete (x4), createTable (x8), addColumn (x2), addPrimaryKey (x6), addForeignKeyConstraint (x9), addUniqueConstraint (x2), addColumn, dropForeignKeyConstraint (x2), dropUniqueConstraint, renameColumn (x3), addUniqueConstraint, addForeignKeyConstra...','',NULL,'3.4.1',NULL,NULL),('1.2.0.RC1','bburke@redhat.com','META-INF/jpa-changelog-1.2.0.CR1.xml','2015-11-24 14:45:28',5,'EXECUTED','7:0f08df48468428e0f30ee59a8ec01a41','delete (x5), createTable (x3), addColumn, createTable (x4), addPrimaryKey (x7), addForeignKeyConstraint (x6), renameColumn, addColumn (x2), update, dropColumn, dropForeignKeyConstraint, renameColumn, addForeignKeyConstraint, dropForeignKeyConstrai...','',NULL,'3.4.1',NULL,NULL),('1.2.0.Final','keycloak','META-INF/jpa-changelog-1.2.0.Final.xml','2015-11-24 14:45:28',6,'EXECUTED','7:a3377a2059aefbf3b90ebb4c4cc8e2ab','update (x3)','',NULL,'3.4.1',NULL,NULL),('1.3.0','bburke@redhat.com','META-INF/jpa-changelog-1.3.0.xml','2015-11-24 14:45:28',7,'EXECUTED','7:04c1dbedc2aa3e9756d1a1668e003451','delete (x6), createTable (x7), addColumn, createTable, addColumn (x2), update, dropDefaultValue, dropColumn, addColumn, update (x4), addPrimaryKey (x4), dropPrimaryKey, dropColumn, addPrimaryKey (x4), addForeignKeyConstraint (x8), dropDefaultValue...','',NULL,'3.4.1',NULL,NULL),('1.4.0','bburke@redhat.com','META-INF/jpa-changelog-1.4.0.xml','2015-11-24 14:45:29',8,'EXECUTED','7:36ef39ed560ad07062d956db861042ba','delete (x7), addColumn (x5), dropColumn, renameTable (x2), update (x10), createTable (x3), customChange, dropPrimaryKey, addPrimaryKey (x4), addForeignKeyConstraint (x2), dropColumn, addColumn','',NULL,'3.4.1',NULL,NULL),('1.5.0','bburke@redhat.com','META-INF/jpa-changelog-1.5.0.xml','2015-11-24 14:45:29',9,'EXECUTED','7:cf12b04b79bea5152f165eb41f3955f6','delete (x7), dropDefaultValue, dropColumn, addColumn (x3)','',NULL,'3.4.1',NULL,NULL),('1.6.1_from15','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2015-11-24 14:45:29',10,'EXECUTED','7:7e32c8f05c755e8675764e7d5f514509','addColumn (x3), createTable (x2), addPrimaryKey (x2)','',NULL,'3.4.1',NULL,NULL),('1.6.1_from16','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2015-11-24 14:45:29',11,'MARK_RAN','7:2fa220758991285312eb84f3b4ff5336','dropPrimaryKey (x2), addColumn, update, dropColumn, addColumn, update, dropColumn, addPrimaryKey (x2)','',NULL,'3.4.1',NULL,NULL),('1.6.1','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2015-11-24 14:45:29',12,'EXECUTED','7:d41d8cd98f00b204e9800998ecf8427e','Empty','',NULL,'3.4.1',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1,'\0',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_ENTITY`
--

DROP TABLE IF EXISTS `EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT_ENTITY` (
  `ID` varchar(36) NOT NULL,
  `CLIENT_ID` varchar(255) DEFAULT NULL,
  `DETAILS_JSON` varchar(2550) DEFAULT NULL,
  `ERROR` varchar(255) DEFAULT NULL,
  `IP_ADDRESS` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `SESSION_ID` varchar(255) DEFAULT NULL,
  `EVENT_TIME` bigint(20) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `USER_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_ENTITY`
--

LOCK TABLES `EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `EVENT_ENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEDERATED_IDENTITY`
--

DROP TABLE IF EXISTS `FEDERATED_IDENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FEDERATED_IDENTITY` (
  `IDENTITY_PROVIDER` varchar(255) NOT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  `FEDERATED_USER_ID` varchar(255) DEFAULT NULL,
  `FEDERATED_USERNAME` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `USER_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`,`USER_ID`),
  KEY `FK404288B92EF007A6` (`USER_ID`),
  CONSTRAINT `FK404288B92EF007A6` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEDERATED_IDENTITY`
--

LOCK TABLES `FEDERATED_IDENTITY` WRITE;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_PROVIDERS`
--

DROP TABLE IF EXISTS `FED_PROVIDERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FED_PROVIDERS` (
  `REALM_ID` varchar(36) NOT NULL,
  `USERFEDERATIONPROVIDERS_ID` varchar(36) NOT NULL,
  UNIQUE KEY `UK_DCCIRJLIPU1478VQC89DID88C` (`USERFEDERATIONPROVIDERS_ID`),
  KEY `FK_213LYQ09FKXQ8K8NY8DY3737T` (`REALM_ID`),
  CONSTRAINT `FK_213LYQ09FKXQ8K8NY8DY3737T` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`),
  CONSTRAINT `FK_DCCIRJLIPU1478VQC89DID88C` FOREIGN KEY (`USERFEDERATIONPROVIDERS_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_PROVIDERS`
--

LOCK TABLES `FED_PROVIDERS` WRITE;
/*!40000 ALTER TABLE `FED_PROVIDERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_PROVIDERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDENTITY_PROVIDER` (
  `INTERNAL_ID` varchar(36) NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ALIAS` varchar(255) DEFAULT NULL,
  `PROVIDER_ID` varchar(255) DEFAULT NULL,
  `STORE_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  `AUTHENTICATE_BY_DEFAULT` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) DEFAULT NULL,
  `ADD_TOKEN_ROLE` bit(1) NOT NULL DEFAULT b'1',
  `TRUST_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `UPDATE_PROFILE_FIRST_LGN_MD` varchar(255) NOT NULL DEFAULT 'on',
  PRIMARY KEY (`INTERNAL_ID`),
  UNIQUE KEY `UK_2DAELWNIBJI49AVXSRTUF6XJ33` (`PROVIDER_ALIAS`,`REALM_ID`),
  KEY `FK2B4EBC52AE5C3B34` (`REALM_ID`),
  CONSTRAINT `FK2B4EBC52AE5C3B34` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER`
--

LOCK TABLES `IDENTITY_PROVIDER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_CONFIG`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDENTITY_PROVIDER_CONFIG` (
  `IDENTITY_PROVIDER_ID` varchar(36) NOT NULL,
  `VALUE` longtext,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FKDC4897CF864C4E43` FOREIGN KEY (`IDENTITY_PROVIDER_ID`) REFERENCES `IDENTITY_PROVIDER` (`INTERNAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_CONFIG`
--

LOCK TABLES `IDENTITY_PROVIDER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_MAPPER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDENTITY_PROVIDER_MAPPER` (
  `ID` varchar(36) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `IDP_ALIAS` varchar(255) NOT NULL,
  `IDP_MAPPER_NAME` varchar(255) NOT NULL,
  `REALM_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_IDPM_REALM` (`REALM_ID`),
  CONSTRAINT `FK_IDPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_MAPPER`
--

LOCK TABLES `IDENTITY_PROVIDER_MAPPER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDP_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `IDP_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IDP_MAPPER_CONFIG` (
  `IDP_MAPPER_ID` varchar(36) NOT NULL,
  `VALUE` longtext,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`IDP_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_IDPMCONFIG` FOREIGN KEY (`IDP_MAPPER_ID`) REFERENCES `IDENTITY_PROVIDER_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDP_MAPPER_CONFIG`
--

LOCK TABLES `IDP_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEYCLOAK_ROLE`
--

DROP TABLE IF EXISTS `KEYCLOAK_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KEYCLOAK_ROLE` (
  `ID` varchar(36) NOT NULL,
  `CLIENT_REALM_CONSTRAINT` varchar(36) DEFAULT NULL,
  `CLIENT_ROLE` bit(1) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `CLIENT` varchar(36) DEFAULT NULL,
  `REALM` varchar(36) DEFAULT NULL,
  `SCOPE_PARAM_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_J3RWUVD56ONTGSUHOGM184WW2-2` (`NAME`,`CLIENT_REALM_CONSTRAINT`),
  KEY `FK_6VYQFE4CN4WLQ8R6KT5VDSJ5C` (`REALM`),
  KEY `FK_KJHO5LE2C0RAL09FL8CM9WFW9` (`CLIENT`),
  CONSTRAINT `FK_6VYQFE4CN4WLQ8R6KT5VDSJ5C` FOREIGN KEY (`REALM`) REFERENCES `REALM` (`ID`),
  CONSTRAINT `FK_KJHO5LE2C0RAL09FL8CM9WFW9` FOREIGN KEY (`CLIENT`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEYCLOAK_ROLE`
--

LOCK TABLES `KEYCLOAK_ROLE` WRITE;
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` DISABLE KEYS */;
INSERT INTO `KEYCLOAK_ROLE` VALUES ('00f7173b-9ce5-41e6-9e10-bdeb44a10b71','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_create-client}','create-client','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('0a6eca76-3d2c-499e-90a8-47e8e2519a01','eb90332f-156d-4cec-8952-857232b91b3d','','${role_manage-events}','manage-events','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('0f3702a1-7b7f-481d-bca0-87107a3b9892','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_view-clients}','view-clients','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('109ee28a-b5cb-4d56-80f7-86a985a98356','eb90332f-156d-4cec-8952-857232b91b3d','','${role_view-events}','view-events','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('12477919-cb52-49a4-91d1-c8216ad4bf2e','dina','\0',NULL,'user','dina',NULL,'dina','\0'),('14204586-f6d4-4638-ba6c-a7b0b53b6ae1','eb90332f-156d-4cec-8952-857232b91b3d','','${role_manage-identity-providers}','manage-identity-providers','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('1a3dcf36-1554-4a14-b78d-ca52c64e8466','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_manage-identity-providers}','manage-identity-providers','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('23f7a6df-098b-4c48-8e47-83236b2cdea1','eb90332f-156d-4cec-8952-857232b91b3d','','${role_view-clients}','view-clients','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('28ee72d6-db09-498a-a12f-5270baee8ac7','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_view-events}','view-events','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('2a890a5a-caa8-40e1-adac-324a82da1db4','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_view-identity-providers}','view-identity-providers','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('2ed48f4b-45f9-48df-baf9-f996f1970b42','5040b99e-aabf-4164-8780-0fc67c193318','',NULL,'admin','dina','5040b99e-aabf-4164-8780-0fc67c193318',NULL,'\0'),('3788ee74-5d1c-4d95-97a1-2b719c576621','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_view-realm}','view-realm','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('3981c710-535b-4c3d-a895-75d6f1328c54','dina','\0',NULL,'admin','dina',NULL,'dina','\0'),('3fc85fdd-9bbd-4fef-bb0c-b77074fce0f9','eb90332f-156d-4cec-8952-857232b91b3d','','${role_view-users}','view-users','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('43dc4719-7482-4f38-a4e5-7f57d9534e81','2d57c124-63e6-4f07-977c-79167ff268f8','',NULL,'admin','dina','2d57c124-63e6-4f07-977c-79167ff268f8',NULL,'\0'),('46bf6243-48ff-4205-8f31-6f0c08d08fe6','dina','\0','${role_offline-access}','offline_access','dina',NULL,'dina',''),('50fa9e38-361a-47e6-b7f3-db92daf750be','c72b4202-09f9-4f37-a4ca-62b3e91bcab7','',NULL,'admin','dina','c72b4202-09f9-4f37-a4ca-62b3e91bcab7',NULL,'\0'),('5441adde-c3f5-431e-a04c-ba7ea1c5c6b7','4f8273ca-19e1-47f8-acbf-ed2359a6ada0','','${role_read-token}','read-token','master','4f8273ca-19e1-47f8-acbf-ed2359a6ada0',NULL,'\0'),('5488bc80-23cd-4e32-9b74-10e844df3ae6','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_manage-events}','manage-events','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('56005e3b-9399-427c-b40a-28078fa8a0f8','eb90332f-156d-4cec-8952-857232b91b3d','','${role_manage-users}','manage-users','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('58750b48-fde2-405d-9c75-d412c6888841','master','\0','${role_create-realm}','create-realm','master',NULL,'master','\0'),('5b20491e-ff7f-4b24-9ae6-58e611b8e27e','eb90332f-156d-4cec-8952-857232b91b3d','','${role_realm-admin}','realm-admin','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('5d26f4a7-4966-4244-a8d3-bc2c8124da66','master','\0','${role_offline-access}','offline_access','master',NULL,'master',''),('5e4a85a2-f2ee-44a7-9bac-8c1c06696562','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_manage-events}','manage-events','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('5e8d8ed7-7855-4c37-b164-dfd946800137','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_impersonation}','impersonation','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('5f3e5f0f-e934-478c-a27e-beedf986eb87','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_view-realm}','view-realm','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('5f4ba0d4-ff2c-42c4-bb9a-245dc53caef5','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_manage-clients}','manage-clients','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('681b2094-847f-4a86-85c7-19e41dbb9018','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_create-client}','create-client','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('689c6c31-ed5e-4f8c-8898-d1d9107834fd','c72b4202-09f9-4f37-a4ca-62b3e91bcab7','',NULL,'user','dina','c72b4202-09f9-4f37-a4ca-62b3e91bcab7',NULL,'\0'),('7449b873-c42b-4081-b4e8-3480972417da','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_impersonation}','impersonation','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('750a49ad-d013-4999-970b-7a322e63b203','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','',NULL,'user','dina','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c',NULL,'\0'),('78ecfd66-d7d6-4be2-aaec-6ea702cf3161','eb90332f-156d-4cec-8952-857232b91b3d','','${role_view-identity-providers}','view-identity-providers','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('7e9c4920-fa7c-486f-ae70-d38c82fd13ea','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_view-clients}','view-clients','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('7f422e78-651b-40e6-81a9-d7e8b0cc27cc','eb90332f-156d-4cec-8952-857232b91b3d','','${role_manage-clients}','manage-clients','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('89ffb599-3910-4588-b155-8e8518682175','12a00924-5501-4a34-a368-2be92698759c','','${role_view-profile}','view-profile','dina','12a00924-5501-4a34-a368-2be92698759c',NULL,'\0'),('8f59422c-4890-4379-bc66-ac02cd406613','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_manage-clients}','manage-clients','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('99b83880-32ee-4ffe-827c-0bfdd9acb303','12a00924-5501-4a34-a368-2be92698759c','','${role_manage-account}','manage-account','dina','12a00924-5501-4a34-a368-2be92698759c',NULL,'\0'),('a4197d73-cbde-4d8d-bd4e-82fe1e5bc9d9','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_view-events}','view-events','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('a43b78d0-c1d1-46ec-b88c-cdda858bb987','eb90332f-156d-4cec-8952-857232b91b3d','','${role_impersonation}','impersonation','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('a9646aae-c487-4429-befd-9172700fc452','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_manage-realm}','manage-realm','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('aca41b88-1dbe-42af-8cbd-dae75a508d22','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_manage-users}','manage-users','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('b9640b04-5396-439f-8e4b-7bffff950f59','f7b7fe46-ec29-4f68-95be-fbf3d55afc01','','${role_view-profile}','view-profile','master','f7b7fe46-ec29-4f68-95be-fbf3d55afc01',NULL,'\0'),('c7005553-f54d-4885-b2c7-7f74feb65210','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_manage-realm}','manage-realm','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('cf014c94-719d-49a8-8f65-fb931bba7691','2d57c124-63e6-4f07-977c-79167ff268f8','',NULL,'user','dina','2d57c124-63e6-4f07-977c-79167ff268f8',NULL,'\0'),('d646f695-1652-431a-bf99-bf422e5147e0','5040b99e-aabf-4164-8780-0fc67c193318','',NULL,'user','dina','5040b99e-aabf-4164-8780-0fc67c193318',NULL,'\0'),('d8eec9a7-a05d-48d9-93ef-a82293979dec','f7b7fe46-ec29-4f68-95be-fbf3d55afc01','','${role_manage-account}','manage-account','master','f7b7fe46-ec29-4f68-95be-fbf3d55afc01',NULL,'\0'),('dd967270-5122-4f32-af94-698dd3fda606','eb90332f-156d-4cec-8952-857232b91b3d','','${role_view-realm}','view-realm','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('dee3af16-4f7c-437d-b1b8-ca0c3d841695','eb90332f-156d-4cec-8952-857232b91b3d','','${role_manage-realm}','manage-realm','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('df01c91b-2d5f-4a9c-bcb2-c73607eb6cfe','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_view-users}','view-users','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('df94a3b9-9f58-47ae-9f60-834ce86f46be','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c','',NULL,'admin','dina','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c',NULL,'\0'),('e1964767-7883-465b-8f69-9e853a698aac','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_view-identity-providers}','view-identity-providers','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('e9e6b449-24c7-4f5e-905e-487ee260d676','370b6760-428e-4b14-850b-a9bfd25fcd8c','','${role_view-users}','view-users','master','370b6760-428e-4b14-850b-a9bfd25fcd8c',NULL,'\0'),('ed101cd9-aecc-4fb3-9fdc-75ae13c079aa','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_manage-users}','manage-users','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('ef1ec7c6-cab0-4d2f-a09c-c290cd97da97','dc20d618-412c-4502-93d6-e4e90d0f3e70','','${role_manage-identity-providers}','manage-identity-providers','master','dc20d618-412c-4502-93d6-e4e90d0f3e70',NULL,'\0'),('f31cfa8c-50ae-4048-bebf-e79c12d6e14f','eb90332f-156d-4cec-8952-857232b91b3d','','${role_create-client}','create-client','dina','eb90332f-156d-4cec-8952-857232b91b3d',NULL,'\0'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','master','\0','${role_admin}','admin','master',NULL,'master','\0'),('f8d4f282-91b5-4530-90b6-6c911a8b4f61','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4','','${role_read-token}','read-token','dina','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4',NULL,'\0');
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATION_MODEL`
--

DROP TABLE IF EXISTS `MIGRATION_MODEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MIGRATION_MODEL` (
  `ID` varchar(36) NOT NULL,
  `VERSION` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATION_MODEL`
--

LOCK TABLES `MIGRATION_MODEL` WRITE;
/*!40000 ALTER TABLE `MIGRATION_MODEL` DISABLE KEYS */;
INSERT INTO `MIGRATION_MODEL` VALUES ('SINGLETON','1.6.0');
/*!40000 ALTER TABLE `MIGRATION_MODEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_CLIENT_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_CLIENT_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OFFLINE_CLIENT_SESSION` (
  `CLIENT_SESSION_ID` varchar(36) NOT NULL,
  `USER_SESSION_ID` varchar(36) NOT NULL,
  `CLIENT_ID` varchar(36) NOT NULL,
  `OFFLINE_FLAG` varchar(4) NOT NULL,
  `TIMESTAMP` int(11) DEFAULT NULL,
  `DATA` longtext,
  PRIMARY KEY (`CLIENT_SESSION_ID`,`OFFLINE_FLAG`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_CLIENT_SESSION`
--

LOCK TABLES `OFFLINE_CLIENT_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_USER_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_USER_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OFFLINE_USER_SESSION` (
  `USER_SESSION_ID` varchar(36) NOT NULL,
  `USER_ID` varchar(36) NOT NULL,
  `REALM_ID` varchar(36) NOT NULL,
  `LAST_SESSION_REFRESH` int(11) DEFAULT NULL,
  `OFFLINE_FLAG` varchar(4) NOT NULL,
  `DATA` longtext,
  PRIMARY KEY (`USER_SESSION_ID`,`OFFLINE_FLAG`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_USER_SESSION`
--

LOCK TABLES `OFFLINE_USER_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROTOCOL_MAPPER` (
  `ID` varchar(36) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PROTOCOL` varchar(255) NOT NULL,
  `PROTOCOL_MAPPER_NAME` varchar(255) NOT NULL,
  `CONSENT_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `CONSENT_TEXT` varchar(255) DEFAULT NULL,
  `CLIENT_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_PCM_REALM` (`CLIENT_ID`),
  CONSTRAINT `FK_PCM_REALM` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER`
--

LOCK TABLES `PROTOCOL_MAPPER` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER` VALUES ('00ee4041-bc3e-4120-b09e-16f76e95749a','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','5040b99e-aabf-4164-8780-0fc67c193318'),('0952abbd-d8d7-4e82-9b84-5e6ab22070f6','role list','saml','saml-role-list-mapper','\0',NULL,'dc20d618-412c-4502-93d6-e4e90d0f3e70'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','email','openid-connect','oidc-usermodel-property-mapper','','${email}','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('0e9074fa-b35f-455c-8ef6-e101f55a4fd1','full name','openid-connect','oidc-full-name-mapper','','${fullName}','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','email','openid-connect','oidc-usermodel-property-mapper','','${email}','370b6760-428e-4b14-850b-a9bfd25fcd8c'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','username','openid-connect','oidc-usermodel-property-mapper','','${username}','b0276453-5047-40e9-a07d-d3da942fb21e'),('21304bf4-7a06-4682-a3fa-832f4a44440e','email','openid-connect','oidc-usermodel-property-mapper','','${email}','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','b0276453-5047-40e9-a07d-d3da942fb21e'),('2c067e84-05be-4395-a214-a40f87722b18','email','openid-connect','oidc-usermodel-property-mapper','','${email}','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('2f4c2d20-0754-449c-b1f0-7dc3166393bf','role list','saml','saml-role-list-mapper','\0',NULL,'b0276453-5047-40e9-a07d-d3da942fb21e'),('30fe7088-deac-4669-90d4-a3639e67a0c1','username','openid-connect','oidc-usermodel-property-mapper','','${username}','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','username','openid-connect','oidc-usermodel-property-mapper','','${username}','2d57c124-63e6-4f07-977c-79167ff268f8'),('341a4229-aaa7-4b70-8275-805fe173c655','role list','saml','saml-role-list-mapper','\0',NULL,'4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('3758cde1-bf30-49b7-8510-7b4af66bf8f4','full name','openid-connect','oidc-full-name-mapper','','${fullName}','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('3e341c56-83bc-46d9-8e9c-8d726e84b1a4','role list','saml','saml-role-list-mapper','\0',NULL,'370b6760-428e-4b14-850b-a9bfd25fcd8c'),('405dd869-423a-408d-8f93-447b0356e33d','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('499ca86b-9e19-432a-8295-58c7784556b0','username','openid-connect','oidc-usermodel-property-mapper','','${username}','cd875af9-7482-4bcc-a875-32d45029742f'),('5123fdf0-df74-4746-a90e-c40c2b9ceb22','role list','saml','saml-role-list-mapper','\0',NULL,'5040b99e-aabf-4164-8780-0fc67c193318'),('52f2bd89-bb27-44d1-8969-8f2278381193','full name','openid-connect','oidc-full-name-mapper','','${fullName}','2d57c124-63e6-4f07-977c-79167ff268f8'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','email','openid-connect','oidc-usermodel-property-mapper','','${email}','5040b99e-aabf-4164-8780-0fc67c193318'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','username','openid-connect','oidc-usermodel-property-mapper','','${username}','5040b99e-aabf-4164-8780-0fc67c193318'),('64763576-e4f9-45ca-af70-b3524af2d90d','Client ID','openid-connect','oidc-usersessionmodel-note-mapper','\0','','2d57c124-63e6-4f07-977c-79167ff268f8'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('664792ee-81d5-4ef9-8e66-448cb3bad04e','full name','openid-connect','oidc-full-name-mapper','','${fullName}','5040b99e-aabf-4164-8780-0fc67c193318'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','email','openid-connect','oidc-usermodel-property-mapper','','${email}','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('672174f7-fd70-481c-8bb6-ceb53f50792d','username','openid-connect','oidc-usermodel-property-mapper','','${username}','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('6c110b78-ab75-4887-ba3b-de31280d0181','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','2d57c124-63e6-4f07-977c-79167ff268f8'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','12a00924-5501-4a34-a368-2be92698759c'),('75ba6c69-b6d7-4a03-9a7b-c73e6406ef31','role list','saml','saml-role-list-mapper','\0',NULL,'bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('7d53b463-9414-4974-9470-983b364534b9','Client IP Address','openid-connect','oidc-usersessionmodel-note-mapper','\0','','2d57c124-63e6-4f07-977c-79167ff268f8'),('7f837027-8712-4c11-aae2-9c66c6e0158c','full name','openid-connect','oidc-full-name-mapper','','${fullName}','370b6760-428e-4b14-850b-a9bfd25fcd8c'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','b0276453-5047-40e9-a07d-d3da942fb21e'),('8030c44a-6f45-4471-9f31-99dfffc3423d','role list','saml','saml-role-list-mapper','\0',NULL,'fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','username','openid-connect','oidc-usermodel-property-mapper','','${username}','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('83eb1195-fb4c-4c49-b396-1b4e28bb17b9','role list','saml','saml-role-list-mapper','\0',NULL,'c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('87443516-b156-42f8-bcd1-6d95a35295d9','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','eb90332f-156d-4cec-8952-857232b91b3d'),('87c60815-c107-4349-b1e9-e316a3041489','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('88259cd0-a805-41e2-8a7d-12a1ce8bf189','role list','saml','saml-role-list-mapper','\0',NULL,'f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('90833dde-d416-4fe9-aeff-04fba1763671','full name','openid-connect','oidc-full-name-mapper','','${fullName}','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('94bc4979-ee82-483d-8bbe-7d71f502d4c1','role list','saml','saml-role-list-mapper','\0',NULL,'cd875af9-7482-4bcc-a875-32d45029742f'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','username','openid-connect','oidc-usermodel-property-mapper','','${username}','12a00924-5501-4a34-a368-2be92698759c'),('9546dabf-d601-473b-8c98-46d2d716ad72','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('97ddbc94-4dea-453c-a5d4-586783b84788','username','openid-connect','oidc-usermodel-property-mapper','','${username}','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('9c4cebc1-8994-481b-887f-2293be67557c','full name','openid-connect','oidc-full-name-mapper','','${fullName}','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','email','openid-connect','oidc-usermodel-property-mapper','','${email}','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('a57c6063-c83e-45c0-96a1-a79d309708d7','username','openid-connect','oidc-usermodel-property-mapper','','${username}','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('a675d1db-d679-4951-a84e-29d5b1778dee','role list','saml','saml-role-list-mapper','\0',NULL,'eb90332f-156d-4cec-8952-857232b91b3d'),('a8bb5fb4-e9c9-4b16-8f1b-8ad4eaa72b6a','full name','openid-connect','oidc-full-name-mapper','','${fullName}','eb90332f-156d-4cec-8952-857232b91b3d'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','email','openid-connect','oidc-usermodel-property-mapper','','${email}','12a00924-5501-4a34-a368-2be92698759c'),('af522e0c-6956-4f09-9eef-300d526710e2','full name','openid-connect','oidc-full-name-mapper','','${fullName}','cd875af9-7482-4bcc-a875-32d45029742f'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','email','openid-connect','oidc-usermodel-property-mapper','','${email}','b0276453-5047-40e9-a07d-d3da942fb21e'),('b2b3060e-a5ab-4e4d-97ce-7607dfc43bac','full name','openid-connect','oidc-full-name-mapper','','${fullName}','b0276453-5047-40e9-a07d-d3da942fb21e'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','Client Host','openid-connect','oidc-usersessionmodel-note-mapper','\0','','2d57c124-63e6-4f07-977c-79167ff268f8'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','locale','openid-connect','oidc-usermodel-attribute-mapper','\0','${locale}','b0276453-5047-40e9-a07d-d3da942fb21e'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','email','openid-connect','oidc-usermodel-property-mapper','','${email}','eb90332f-156d-4cec-8952-857232b91b3d'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','5040b99e-aabf-4164-8780-0fc67c193318'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','email','openid-connect','oidc-usermodel-property-mapper','','${email}','2d57c124-63e6-4f07-977c-79167ff268f8'),('bb6cedc7-dad5-4544-94ff-f97451008729','full name','openid-connect','oidc-full-name-mapper','','${fullName}','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('bff1ccad-a8de-4565-a1ad-eb90d43e9b43','role list','saml','saml-role-list-mapper','\0',NULL,'12a00924-5501-4a34-a368-2be92698759c'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','locale','openid-connect','oidc-usermodel-attribute-mapper','\0','${locale}','cd875af9-7482-4bcc-a875-32d45029742f'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','2d57c124-63e6-4f07-977c-79167ff268f8'),('c9d66028-bbb9-475d-ad31-61b83334b12d','username','openid-connect','oidc-usermodel-property-mapper','','${username}','eb90332f-156d-4cec-8952-857232b91b3d'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','email','openid-connect','oidc-usermodel-property-mapper','','${email}','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','email','openid-connect','oidc-usermodel-property-mapper','','${email}','cd875af9-7482-4bcc-a875-32d45029742f'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','12a00924-5501-4a34-a368-2be92698759c'),('d3dc94d1-d420-4a0d-96ae-7cd74215350e','full name','openid-connect','oidc-full-name-mapper','','${fullName}','12a00924-5501-4a34-a368-2be92698759c'),('d4525e27-328d-4848-b948-56dbf590119b','username','openid-connect','oidc-usermodel-property-mapper','','${username}','370b6760-428e-4b14-850b-a9bfd25fcd8c'),('dc0dd933-d2c3-4e21-b549-1e15c2b62ca3','full name','openid-connect','oidc-full-name-mapper','','${fullName}','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','cd875af9-7482-4bcc-a875-32d45029742f'),('eca4fb2d-40ba-4c88-99fe-b216b7a04847','role list','saml','saml-role-list-mapper','\0',NULL,'2d57c124-63e6-4f07-977c-79167ff268f8'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','370b6760-428e-4b14-850b-a9bfd25fcd8c'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','cd875af9-7482-4bcc-a875-32d45029742f'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','given name','openid-connect','oidc-usermodel-property-mapper','','${givenName}','eb90332f-156d-4cec-8952-857232b91b3d'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','username','openid-connect','oidc-usermodel-property-mapper','','${username}','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('ffe24063-ff72-4639-938b-542f5ec68735','family name','openid-connect','oidc-usermodel-property-mapper','','${familyName}','370b6760-428e-4b14-850b-a9bfd25fcd8c');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROTOCOL_MAPPER_CONFIG` (
  `PROTOCOL_MAPPER_ID` varchar(36) NOT NULL,
  `VALUE` longtext,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`PROTOCOL_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_PMCONFIG` FOREIGN KEY (`PROTOCOL_MAPPER_ID`) REFERENCES `PROTOCOL_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER_CONFIG`
--

LOCK TABLES `PROTOCOL_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('00ee4041-bc3e-4120-b09e-16f76e95749a','true','access.token.claim'),('00ee4041-bc3e-4120-b09e-16f76e95749a','given_name','claim.name'),('00ee4041-bc3e-4120-b09e-16f76e95749a','true','id.token.claim'),('00ee4041-bc3e-4120-b09e-16f76e95749a','String','jsonType.label'),('00ee4041-bc3e-4120-b09e-16f76e95749a','firstName','user.attribute'),('0952abbd-d8d7-4e82-9b84-5e6ab22070f6','Role','attribute.name'),('0952abbd-d8d7-4e82-9b84-5e6ab22070f6','Basic','attribute.nameformat'),('0952abbd-d8d7-4e82-9b84-5e6ab22070f6','false','single'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','true','access.token.claim'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','email','claim.name'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','true','id.token.claim'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','String','jsonType.label'),('0983662a-f3fa-4ef3-bd06-3289a2bc512b','email','user.attribute'),('0e9074fa-b35f-455c-8ef6-e101f55a4fd1','true','access.token.claim'),('0e9074fa-b35f-455c-8ef6-e101f55a4fd1','true','id.token.claim'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','true','access.token.claim'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','email','claim.name'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','true','id.token.claim'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','String','jsonType.label'),('0fbafc8f-1047-4194-8dc2-e56a485839b5','email','user.attribute'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','true','access.token.claim'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','preferred_username','claim.name'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','true','id.token.claim'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','String','jsonType.label'),('1ae7692d-61a3-4b6b-b968-60a1c444c56f','username','user.attribute'),('21304bf4-7a06-4682-a3fa-832f4a44440e','true','access.token.claim'),('21304bf4-7a06-4682-a3fa-832f4a44440e','email','claim.name'),('21304bf4-7a06-4682-a3fa-832f4a44440e','true','id.token.claim'),('21304bf4-7a06-4682-a3fa-832f4a44440e','String','jsonType.label'),('21304bf4-7a06-4682-a3fa-832f4a44440e','email','user.attribute'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','true','access.token.claim'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','family_name','claim.name'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','true','id.token.claim'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','String','jsonType.label'),('272b1dca-b5b9-4996-9c39-a35a95e329d7','lastName','user.attribute'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','true','access.token.claim'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','given_name','claim.name'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','true','id.token.claim'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','String','jsonType.label'),('27d4af28-c1f2-4dc5-93cd-866fc6e6e120','firstName','user.attribute'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','true','access.token.claim'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','given_name','claim.name'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','true','id.token.claim'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','String','jsonType.label'),('293f0a13-a31f-43b3-b183-a927d4ee79a6','firstName','user.attribute'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','true','access.token.claim'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','given_name','claim.name'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','true','id.token.claim'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','String','jsonType.label'),('29771298-4e28-445d-9bd4-a3f5880f2ab8','firstName','user.attribute'),('2c067e84-05be-4395-a214-a40f87722b18','true','access.token.claim'),('2c067e84-05be-4395-a214-a40f87722b18','email','claim.name'),('2c067e84-05be-4395-a214-a40f87722b18','true','id.token.claim'),('2c067e84-05be-4395-a214-a40f87722b18','String','jsonType.label'),('2c067e84-05be-4395-a214-a40f87722b18','email','user.attribute'),('2f4c2d20-0754-449c-b1f0-7dc3166393bf','Role','attribute.name'),('2f4c2d20-0754-449c-b1f0-7dc3166393bf','Basic','attribute.nameformat'),('2f4c2d20-0754-449c-b1f0-7dc3166393bf','false','single'),('30fe7088-deac-4669-90d4-a3639e67a0c1','true','access.token.claim'),('30fe7088-deac-4669-90d4-a3639e67a0c1','preferred_username','claim.name'),('30fe7088-deac-4669-90d4-a3639e67a0c1','true','id.token.claim'),('30fe7088-deac-4669-90d4-a3639e67a0c1','String','jsonType.label'),('30fe7088-deac-4669-90d4-a3639e67a0c1','username','user.attribute'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','true','access.token.claim'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','preferred_username','claim.name'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','true','id.token.claim'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','String','jsonType.label'),('33ca4bea-3117-4196-8dc5-d032bcb4cc8c','username','user.attribute'),('341a4229-aaa7-4b70-8275-805fe173c655','Role','attribute.name'),('341a4229-aaa7-4b70-8275-805fe173c655','Basic','attribute.nameformat'),('341a4229-aaa7-4b70-8275-805fe173c655','false','single'),('3758cde1-bf30-49b7-8510-7b4af66bf8f4','true','access.token.claim'),('3758cde1-bf30-49b7-8510-7b4af66bf8f4','true','id.token.claim'),('3e341c56-83bc-46d9-8e9c-8d726e84b1a4','Role','attribute.name'),('3e341c56-83bc-46d9-8e9c-8d726e84b1a4','Basic','attribute.nameformat'),('3e341c56-83bc-46d9-8e9c-8d726e84b1a4','false','single'),('405dd869-423a-408d-8f93-447b0356e33d','true','access.token.claim'),('405dd869-423a-408d-8f93-447b0356e33d','family_name','claim.name'),('405dd869-423a-408d-8f93-447b0356e33d','true','id.token.claim'),('405dd869-423a-408d-8f93-447b0356e33d','String','jsonType.label'),('405dd869-423a-408d-8f93-447b0356e33d','lastName','user.attribute'),('499ca86b-9e19-432a-8295-58c7784556b0','true','access.token.claim'),('499ca86b-9e19-432a-8295-58c7784556b0','preferred_username','claim.name'),('499ca86b-9e19-432a-8295-58c7784556b0','true','id.token.claim'),('499ca86b-9e19-432a-8295-58c7784556b0','String','jsonType.label'),('499ca86b-9e19-432a-8295-58c7784556b0','username','user.attribute'),('5123fdf0-df74-4746-a90e-c40c2b9ceb22','Role','attribute.name'),('5123fdf0-df74-4746-a90e-c40c2b9ceb22','Basic','attribute.nameformat'),('5123fdf0-df74-4746-a90e-c40c2b9ceb22','false','single'),('52f2bd89-bb27-44d1-8969-8f2278381193','true','access.token.claim'),('52f2bd89-bb27-44d1-8969-8f2278381193','true','id.token.claim'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','true','access.token.claim'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','email','claim.name'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','true','id.token.claim'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','String','jsonType.label'),('57db4b88-47de-46bf-8b12-dc743bcaa9a3','email','user.attribute'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','true','access.token.claim'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','preferred_username','claim.name'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','true','id.token.claim'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','String','jsonType.label'),('5c8e53b3-e846-4ec4-8e50-0148c936bc1c','username','user.attribute'),('64763576-e4f9-45ca-af70-b3524af2d90d','true','access.token.claim'),('64763576-e4f9-45ca-af70-b3524af2d90d','clientId','claim.name'),('64763576-e4f9-45ca-af70-b3524af2d90d','true','id.token.claim'),('64763576-e4f9-45ca-af70-b3524af2d90d','String','jsonType.label'),('64763576-e4f9-45ca-af70-b3524af2d90d','clientId','user.session.note'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','true','access.token.claim'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','family_name','claim.name'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','true','id.token.claim'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','String','jsonType.label'),('65c79c9f-af7b-4b99-abb3-45a3412d3d7a','lastName','user.attribute'),('664792ee-81d5-4ef9-8e66-448cb3bad04e','true','access.token.claim'),('664792ee-81d5-4ef9-8e66-448cb3bad04e','true','id.token.claim'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','true','access.token.claim'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','email','claim.name'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','true','id.token.claim'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','String','jsonType.label'),('66b53dba-e3c5-4cb4-8557-7b0e152aeb1c','email','user.attribute'),('672174f7-fd70-481c-8bb6-ceb53f50792d','true','access.token.claim'),('672174f7-fd70-481c-8bb6-ceb53f50792d','preferred_username','claim.name'),('672174f7-fd70-481c-8bb6-ceb53f50792d','true','id.token.claim'),('672174f7-fd70-481c-8bb6-ceb53f50792d','String','jsonType.label'),('672174f7-fd70-481c-8bb6-ceb53f50792d','username','user.attribute'),('6c110b78-ab75-4887-ba3b-de31280d0181','true','access.token.claim'),('6c110b78-ab75-4887-ba3b-de31280d0181','family_name','claim.name'),('6c110b78-ab75-4887-ba3b-de31280d0181','true','id.token.claim'),('6c110b78-ab75-4887-ba3b-de31280d0181','String','jsonType.label'),('6c110b78-ab75-4887-ba3b-de31280d0181','lastName','user.attribute'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','true','access.token.claim'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','given_name','claim.name'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','true','id.token.claim'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','String','jsonType.label'),('739c0122-8725-452b-bfc5-15e4fd65e9cf','firstName','user.attribute'),('75ba6c69-b6d7-4a03-9a7b-c73e6406ef31','Role','attribute.name'),('75ba6c69-b6d7-4a03-9a7b-c73e6406ef31','Basic','attribute.nameformat'),('75ba6c69-b6d7-4a03-9a7b-c73e6406ef31','false','single'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','true','access.token.claim'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','family_name','claim.name'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','true','id.token.claim'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','String','jsonType.label'),('7a97ef76-2afd-41e8-8f72-74d5e231ea08','lastName','user.attribute'),('7d53b463-9414-4974-9470-983b364534b9','true','access.token.claim'),('7d53b463-9414-4974-9470-983b364534b9','clientAddress','claim.name'),('7d53b463-9414-4974-9470-983b364534b9','true','id.token.claim'),('7d53b463-9414-4974-9470-983b364534b9','String','jsonType.label'),('7d53b463-9414-4974-9470-983b364534b9','clientAddress','user.session.note'),('7f837027-8712-4c11-aae2-9c66c6e0158c','true','access.token.claim'),('7f837027-8712-4c11-aae2-9c66c6e0158c','true','id.token.claim'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','true','access.token.claim'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','family_name','claim.name'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','true','id.token.claim'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','String','jsonType.label'),('7fb17a42-cd79-4bc8-8aa9-564dcdc0f0bc','lastName','user.attribute'),('8030c44a-6f45-4471-9f31-99dfffc3423d','Role','attribute.name'),('8030c44a-6f45-4471-9f31-99dfffc3423d','Basic','attribute.nameformat'),('8030c44a-6f45-4471-9f31-99dfffc3423d','false','single'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','true','access.token.claim'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','preferred_username','claim.name'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','true','id.token.claim'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','String','jsonType.label'),('81d2b0f2-b4a9-4de3-a6b8-425673026506','username','user.attribute'),('83eb1195-fb4c-4c49-b396-1b4e28bb17b9','Role','attribute.name'),('83eb1195-fb4c-4c49-b396-1b4e28bb17b9','Basic','attribute.nameformat'),('83eb1195-fb4c-4c49-b396-1b4e28bb17b9','false','single'),('87443516-b156-42f8-bcd1-6d95a35295d9','true','access.token.claim'),('87443516-b156-42f8-bcd1-6d95a35295d9','family_name','claim.name'),('87443516-b156-42f8-bcd1-6d95a35295d9','true','id.token.claim'),('87443516-b156-42f8-bcd1-6d95a35295d9','String','jsonType.label'),('87443516-b156-42f8-bcd1-6d95a35295d9','lastName','user.attribute'),('87c60815-c107-4349-b1e9-e316a3041489','true','access.token.claim'),('87c60815-c107-4349-b1e9-e316a3041489','given_name','claim.name'),('87c60815-c107-4349-b1e9-e316a3041489','true','id.token.claim'),('87c60815-c107-4349-b1e9-e316a3041489','String','jsonType.label'),('87c60815-c107-4349-b1e9-e316a3041489','firstName','user.attribute'),('88259cd0-a805-41e2-8a7d-12a1ce8bf189','Role','attribute.name'),('88259cd0-a805-41e2-8a7d-12a1ce8bf189','Basic','attribute.nameformat'),('88259cd0-a805-41e2-8a7d-12a1ce8bf189','false','single'),('90833dde-d416-4fe9-aeff-04fba1763671','true','access.token.claim'),('90833dde-d416-4fe9-aeff-04fba1763671','true','id.token.claim'),('94bc4979-ee82-483d-8bbe-7d71f502d4c1','Role','attribute.name'),('94bc4979-ee82-483d-8bbe-7d71f502d4c1','Basic','attribute.nameformat'),('94bc4979-ee82-483d-8bbe-7d71f502d4c1','false','single'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','true','access.token.claim'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','preferred_username','claim.name'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','true','id.token.claim'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','String','jsonType.label'),('94f3e6a6-0e6a-4c7c-9aba-f48f1198b193','username','user.attribute'),('9546dabf-d601-473b-8c98-46d2d716ad72','true','access.token.claim'),('9546dabf-d601-473b-8c98-46d2d716ad72','given_name','claim.name'),('9546dabf-d601-473b-8c98-46d2d716ad72','true','id.token.claim'),('9546dabf-d601-473b-8c98-46d2d716ad72','String','jsonType.label'),('9546dabf-d601-473b-8c98-46d2d716ad72','firstName','user.attribute'),('97ddbc94-4dea-453c-a5d4-586783b84788','true','access.token.claim'),('97ddbc94-4dea-453c-a5d4-586783b84788','preferred_username','claim.name'),('97ddbc94-4dea-453c-a5d4-586783b84788','true','id.token.claim'),('97ddbc94-4dea-453c-a5d4-586783b84788','String','jsonType.label'),('97ddbc94-4dea-453c-a5d4-586783b84788','username','user.attribute'),('9c4cebc1-8994-481b-887f-2293be67557c','true','access.token.claim'),('9c4cebc1-8994-481b-887f-2293be67557c','true','id.token.claim'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','true','access.token.claim'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','email','claim.name'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','true','id.token.claim'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','String','jsonType.label'),('9c5a2f81-09fd-4e7e-87b5-874c419ddb99','email','user.attribute'),('a57c6063-c83e-45c0-96a1-a79d309708d7','true','access.token.claim'),('a57c6063-c83e-45c0-96a1-a79d309708d7','preferred_username','claim.name'),('a57c6063-c83e-45c0-96a1-a79d309708d7','true','id.token.claim'),('a57c6063-c83e-45c0-96a1-a79d309708d7','String','jsonType.label'),('a57c6063-c83e-45c0-96a1-a79d309708d7','username','user.attribute'),('a675d1db-d679-4951-a84e-29d5b1778dee','Role','attribute.name'),('a675d1db-d679-4951-a84e-29d5b1778dee','Basic','attribute.nameformat'),('a675d1db-d679-4951-a84e-29d5b1778dee','false','single'),('a8bb5fb4-e9c9-4b16-8f1b-8ad4eaa72b6a','true','access.token.claim'),('a8bb5fb4-e9c9-4b16-8f1b-8ad4eaa72b6a','true','id.token.claim'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','true','access.token.claim'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','family_name','claim.name'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','true','id.token.claim'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','String','jsonType.label'),('aa7bf37b-fcde-45b6-9f8d-34b137bf2809','lastName','user.attribute'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','true','access.token.claim'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','email','claim.name'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','true','id.token.claim'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','String','jsonType.label'),('ad8fe218-d1f1-44c3-98ed-639ecc232410','email','user.attribute'),('af522e0c-6956-4f09-9eef-300d526710e2','true','access.token.claim'),('af522e0c-6956-4f09-9eef-300d526710e2','true','id.token.claim'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','true','access.token.claim'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','email','claim.name'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','true','id.token.claim'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','String','jsonType.label'),('b08c1883-8333-4863-b7d2-bd5cdaf8367d','email','user.attribute'),('b2b3060e-a5ab-4e4d-97ce-7607dfc43bac','true','access.token.claim'),('b2b3060e-a5ab-4e4d-97ce-7607dfc43bac','true','id.token.claim'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','true','access.token.claim'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','clientHost','claim.name'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','true','id.token.claim'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','String','jsonType.label'),('b39bbf64-8daa-4cdc-a39f-bef192f07534','clientHost','user.session.note'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','true','access.token.claim'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','locale','claim.name'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','true','id.token.claim'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','String','jsonType.label'),('b3c98ae6-a274-4a7d-845c-64f83dc46b25','locale','user.attribute'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','true','access.token.claim'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','email','claim.name'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','true','id.token.claim'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','String','jsonType.label'),('b4d5c94b-aaf3-46f8-8404-268faa1c00d6','email','user.attribute'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','true','access.token.claim'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','family_name','claim.name'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','true','id.token.claim'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','String','jsonType.label'),('b5ed9646-8125-4434-96ec-a127c43e6f1c','lastName','user.attribute'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','true','access.token.claim'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','email','claim.name'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','true','id.token.claim'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','String','jsonType.label'),('ba33c1ff-858c-426c-9bd8-7a0bb6f5d852','email','user.attribute'),('bb6cedc7-dad5-4544-94ff-f97451008729','true','access.token.claim'),('bb6cedc7-dad5-4544-94ff-f97451008729','true','id.token.claim'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','true','access.token.claim'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','family_name','claim.name'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','true','id.token.claim'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','String','jsonType.label'),('bc79eadd-9a6f-4c60-9e80-25005bdcdddd','lastName','user.attribute'),('bff1ccad-a8de-4565-a1ad-eb90d43e9b43','Role','attribute.name'),('bff1ccad-a8de-4565-a1ad-eb90d43e9b43','Basic','attribute.nameformat'),('bff1ccad-a8de-4565-a1ad-eb90d43e9b43','false','single'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','true','access.token.claim'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','locale','claim.name'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','true','id.token.claim'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','String','jsonType.label'),('c0aaa665-e6f2-435b-b6c1-587ab2be1f25','locale','user.attribute'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','true','access.token.claim'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','given_name','claim.name'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','true','id.token.claim'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','String','jsonType.label'),('c33e2152-58c5-48e5-bca2-1aefbf89e1c3','firstName','user.attribute'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','true','access.token.claim'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','given_name','claim.name'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','true','id.token.claim'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','String','jsonType.label'),('c545d6ab-ab2e-4f6c-be0c-512fc6dbf2d5','firstName','user.attribute'),('c9d66028-bbb9-475d-ad31-61b83334b12d','true','access.token.claim'),('c9d66028-bbb9-475d-ad31-61b83334b12d','preferred_username','claim.name'),('c9d66028-bbb9-475d-ad31-61b83334b12d','true','id.token.claim'),('c9d66028-bbb9-475d-ad31-61b83334b12d','String','jsonType.label'),('c9d66028-bbb9-475d-ad31-61b83334b12d','username','user.attribute'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','true','access.token.claim'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','email','claim.name'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','true','id.token.claim'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','String','jsonType.label'),('cb7c31f5-ce1e-4ea7-ad96-70e79634733b','email','user.attribute'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','true','access.token.claim'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','email','claim.name'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','true','id.token.claim'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','String','jsonType.label'),('cd17819d-4a24-4b5c-9e07-3b0523f86679','email','user.attribute'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','true','access.token.claim'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','family_name','claim.name'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','true','id.token.claim'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','String','jsonType.label'),('d1ab0b3f-b8e6-4008-8f56-e6361f613017','lastName','user.attribute'),('d3dc94d1-d420-4a0d-96ae-7cd74215350e','true','access.token.claim'),('d3dc94d1-d420-4a0d-96ae-7cd74215350e','true','id.token.claim'),('d4525e27-328d-4848-b948-56dbf590119b','true','access.token.claim'),('d4525e27-328d-4848-b948-56dbf590119b','preferred_username','claim.name'),('d4525e27-328d-4848-b948-56dbf590119b','true','id.token.claim'),('d4525e27-328d-4848-b948-56dbf590119b','String','jsonType.label'),('d4525e27-328d-4848-b948-56dbf590119b','username','user.attribute'),('dc0dd933-d2c3-4e21-b549-1e15c2b62ca3','true','access.token.claim'),('dc0dd933-d2c3-4e21-b549-1e15c2b62ca3','true','id.token.claim'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','true','access.token.claim'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','family_name','claim.name'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','true','id.token.claim'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','String','jsonType.label'),('dd6b7133-31b8-4dd7-9bc5-5fad4dec7576','lastName','user.attribute'),('eca4fb2d-40ba-4c88-99fe-b216b7a04847','Role','attribute.name'),('eca4fb2d-40ba-4c88-99fe-b216b7a04847','Basic','attribute.nameformat'),('eca4fb2d-40ba-4c88-99fe-b216b7a04847','false','single'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','true','access.token.claim'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','given_name','claim.name'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','true','id.token.claim'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','String','jsonType.label'),('ecc46d8e-4eb3-4880-9f77-dcf1ac866139','firstName','user.attribute'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','true','access.token.claim'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','given_name','claim.name'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','true','id.token.claim'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','String','jsonType.label'),('ee3773b6-2191-450c-b8d6-8b1a2c70e323','firstName','user.attribute'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','true','access.token.claim'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','given_name','claim.name'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','true','id.token.claim'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','String','jsonType.label'),('ef98e97b-3b9c-42a7-98d9-e7e457ba9fee','firstName','user.attribute'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','true','access.token.claim'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','given_name','claim.name'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','true','id.token.claim'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','String','jsonType.label'),('fb59612b-e648-49b2-a5c4-3399e3b6aa6d','firstName','user.attribute'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','true','access.token.claim'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','preferred_username','claim.name'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','true','id.token.claim'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','String','jsonType.label'),('fdce05f9-5ae1-4e6a-97da-924f30b2e743','username','user.attribute'),('ffe24063-ff72-4639-938b-542f5ec68735','true','access.token.claim'),('ffe24063-ff72-4639-938b-542f5ec68735','family_name','claim.name'),('ffe24063-ff72-4639-938b-542f5ec68735','true','id.token.claim'),('ffe24063-ff72-4639-938b-542f5ec68735','String','jsonType.label'),('ffe24063-ff72-4639-938b-542f5ec68735','lastName','user.attribute');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM`
--

DROP TABLE IF EXISTS `REALM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM` (
  `ID` varchar(36) NOT NULL,
  `ACCESS_CODE_LIFESPAN` int(11) DEFAULT NULL,
  `USER_ACTION_LIFESPAN` int(11) DEFAULT NULL,
  `ACCESS_TOKEN_LIFESPAN` int(11) DEFAULT NULL,
  `ACCOUNT_THEME` varchar(255) DEFAULT NULL,
  `ADMIN_THEME` varchar(255) DEFAULT NULL,
  `EMAIL_THEME` varchar(255) DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_EXPIRATION` bigint(20) DEFAULT NULL,
  `LOGIN_THEME` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `NOT_BEFORE` int(11) DEFAULT NULL,
  `PASSWORD_POLICY` varchar(255) DEFAULT NULL,
  `PRIVATE_KEY` varchar(2048) DEFAULT NULL,
  `PUBLIC_KEY` varchar(2048) DEFAULT NULL,
  `REGISTRATION_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `RESET_PASSWORD_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `SOCIAL` bit(1) NOT NULL DEFAULT b'0',
  `SSL_REQUIRED` varchar(255) DEFAULT NULL,
  `SSO_IDLE_TIMEOUT` int(11) DEFAULT NULL,
  `SSO_MAX_LIFESPAN` int(11) DEFAULT NULL,
  `UPDATE_PROFILE_ON_SOC_LOGIN` bit(1) NOT NULL DEFAULT b'0',
  `VERIFY_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `MASTER_ADMIN_CLIENT` varchar(36) DEFAULT NULL,
  `CERTIFICATE` varchar(2048) DEFAULT NULL,
  `CODE_SECRET` varchar(255) DEFAULT NULL,
  `LOGIN_LIFESPAN` int(11) DEFAULT NULL,
  `INTERNATIONALIZATION_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_LOCALE` varchar(255) DEFAULT NULL,
  `REG_EMAIL_AS_USERNAME` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_DETAILS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EDIT_USERNAME_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `OTP_POLICY_COUNTER` int(11) DEFAULT '0',
  `OTP_POLICY_WINDOW` int(11) DEFAULT '1',
  `OTP_POLICY_PERIOD` int(11) DEFAULT '30',
  `OTP_POLICY_DIGITS` int(11) DEFAULT '6',
  `OTP_POLICY_ALG` varchar(36) DEFAULT 'HmacSHA1',
  `OTP_POLICY_TYPE` varchar(36) DEFAULT 'totp',
  `BROWSER_FLOW` varchar(36) DEFAULT NULL,
  `REGISTRATION_FLOW` varchar(36) DEFAULT NULL,
  `DIRECT_GRANT_FLOW` varchar(36) DEFAULT NULL,
  `RESET_CREDENTIALS_FLOW` varchar(36) DEFAULT NULL,
  `CLIENT_AUTH_FLOW` varchar(36) DEFAULT NULL,
  `OFFLINE_SESSION_IDLE_TIMEOUT` int(11) DEFAULT '0',
  `REVOKE_REFRESH_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORVSDMLA56612EAEFIQ6WL5OI` (`NAME`),
  KEY `FK_TRAF444KK6QRKMS7N56AIWQ5Y` (`MASTER_ADMIN_CLIENT`),
  CONSTRAINT `FK_TRAF444KK6QRKMS7N56AIWQ5Y` FOREIGN KEY (`MASTER_ADMIN_CLIENT`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM`
--

LOCK TABLES `REALM` WRITE;
/*!40000 ALTER TABLE `REALM` DISABLE KEYS */;
INSERT INTO `REALM` VALUES ('dina',60,300,10800,NULL,NULL,NULL,'','\0',0,NULL,'dina',1448615806,NULL,'MIIEowIBAAKCAQEAo3scwKWX4TPGfU1oXCOnBRAZzoQQJT1GLEbjWcxs+o/GbihUUTcj7tPv1e0Rsx14EHgmsrKSkRK7DdFhPGGEt1maq4Exjq11LZjS+xCloeSyu/RIFlCcx2KX+WcuRMZGp+bhC99srG7cMKYIPY8TEX/MfDYcPv8Ud9sbVCDjfceJM08q8VAIKvZboSJVaIbxfvbIECGzslNqDJWyWPS2AKts+I7ZW5Q/SLKAoNnTqkBUgSb/bV2/dihmHzJ/dqkVz/rnzes0RR4qlSp3cOBxgA7Z8H3PkhyuVJwbgfB4Z/LX9Doc9aXp91Zft4pezngNAFDyHkw8kNmEhh5z2lYI+QIDAQABAoIBAC8Gpwqzl7DsV9iLf82hY9YM/59sVcigi6MI8TVPnLmmygm+CCMknW2CAaej/kdr3rG+HkOhIpAgtzYOWM4pryee2uMi0sKcGuz23RnjfAHJ67AtYN8qaS7hqZ3QlHqsHn8F5w6nQneHnEdSO2SZ135dKNFCL3Xfol+n44CbxVTUrw1QeIQ+NSMawsCwbr9ldFc0dluF/NjwzWuaQX5QPKAhHfooQZSyN2xYRfIEytqeFHPYwl/ePLDop+EldO/vV6yVCCFaSPT40cjVyD4ie4UjE0QPanOcjDgh/yHEIHOzeA+cA2jFESD6mYwKo9k6jbSnsXfHRvwv/O2DdsSw9RECgYEA3YP+bcg54XEuS5rQYrfRbirWbKV3Dixjq0mtCEBYNKnsFvJHf+P0As6aD8FjCbeXFvTjwZzgRIWEaU4kCbU1wE8QpoakcmVCWCDu3hHgWpy34b28upNedre32xiQ/YbN5GSMFaLxZw0SJkdJuYooCf4HlTKurzi0EVpvZ9IpmTMCgYEAvO5GuDU3e9LummE0dgh74qXBVX8H9agUfHzzrRNtevqL3lFeta+hYBMc6w6TIYQqeabOwPvF7sHayJe7prtBJk1pgxRLIC4pMAVuJ4WjPNyDxrn4IE5w3vT3DjmjPRFvGTdNvIRKdQlJIgvDEHAPY1NBZ1tIZgaFQFzx2qenjSMCgYB74y9v3LSqZi9bL2luXJnvwFuOBfiQ37iaeqkgXUQ3p/UXXEcquqWk0EGPoDuwmpIQz8N1bDRtfjLw5jf3ifZW6KFKUTE1nXY+baTKZDsS0mVxBjnAK12Ajf1wtsuYT0Vlf+psy2WxmbjV2bbc4uzDseQxyFe0PcVPk0GNUhfbywKBgQCetpCkSNhuZflZqVUX3vKrqNFsUEXQgb2MAq/18n8jM3zya2rjuEIZ4pSFhn3lRxEjlxTTG+7gLuvrXUQfwejuE1QS8KZXx0+EbttlyicihqEQ/cNK6Hp7YlB1G8hdEdtB1KqyNnQSM5XDSxw4H9tddmBYQl/kjY+9TRdDt1nS/wKBgCe7/4Fmz9n+InqPady7j0E4vCkP9sASs8fHkDmrZK3aFvy7FLATupMmCq51cqxFOGUaE8hHNQ84jjdP+hhccHqsG5dr1Y6RNWej9eiYWRfs1QztgH4bkbqK1u6po4slBZyL2RmSoMBERFlNofx34izO6Uik5ym6Vr7o4MPQrXDn','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAo3scwKWX4TPGfU1oXCOnBRAZzoQQJT1GLEbjWcxs+o/GbihUUTcj7tPv1e0Rsx14EHgmsrKSkRK7DdFhPGGEt1maq4Exjq11LZjS+xCloeSyu/RIFlCcx2KX+WcuRMZGp+bhC99srG7cMKYIPY8TEX/MfDYcPv8Ud9sbVCDjfceJM08q8VAIKvZboSJVaIbxfvbIECGzslNqDJWyWPS2AKts+I7ZW5Q/SLKAoNnTqkBUgSb/bV2/dihmHzJ/dqkVz/rnzes0RR4qlSp3cOBxgA7Z8H3PkhyuVJwbgfB4Z/LX9Doc9aXp91Zft4pezngNAFDyHkw8kNmEhh5z2lYI+QIDAQAB','\0','\0','\0','\0','EXTERNAL',32400,36000,'\0','\0','370b6760-428e-4b14-850b-a9bfd25fcd8c','MIIClzCCAX8CBgFRRB9k0zANBgkqhkiG9w0BAQsFADAPMQ0wCwYDVQQDDARkaW5hMB4XDTE1MTEyNjE0MDYyNloXDTI1MTEyNjE0MDgwNlowDzENMAsGA1UEAwwEZGluYTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKN7HMCll+Ezxn1NaFwjpwUQGc6EECU9RixG41nMbPqPxm4oVFE3I+7T79XtEbMdeBB4JrKykpESuw3RYTxhhLdZmquBMY6tdS2Y0vsQpaHksrv0SBZQnMdil/lnLkTGRqfm4QvfbKxu3DCmCD2PExF/zHw2HD7/FHfbG1Qg433HiTNPKvFQCCr2W6EiVWiG8X72yBAhs7JTagyVslj0tgCrbPiO2VuUP0iygKDZ06pAVIEm/21dv3YoZh8yf3apFc/6583rNEUeKpUqd3DgcYAO2fB9z5IcrlScG4HweGfy1/Q6HPWl6fdWX7eKXs54DQBQ8h5MPJDZhIYec9pWCPkCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAG/8usNPTgyQK4glNawpLVd+AipwKGzEmZPSR1+doYYvfk2Kro2zRbClc+EToAk3yRtP/y7pXSspEBHP7D4ibCzj+LczzRCTqjxARW6xczASaPW8R9s+S5OlM6f1nmVKHOg+NCydiE+lM9d/N7ybzuWFb8ZlIrTgpOSeZH8qhHZM5R/NypKjnkbL5q3Bg9JSnFbKLvPKW9YQLoHRDqBbq1uTiFYAYR78D9U/R9c3N0oY1hLlMrBxbif4hg2EShmXh1Mv+F5aZtty5VQJxBkpmX0hgLxvjPtdR7PtGHeejQ8mmg5MdnOXQnztvC/nBbsKK2TXO4DEoMgNqja5kzl9IiQ==','add5a654-c326-4bee-8173-f41074f53328',1800,'\0',NULL,'\0','\0','\0','\0',0,1,30,6,'HmacSHA1','totp','83da829e-be7f-4469-8558-1fc768c03f52','232581d1-102f-4720-8be9-1140c692ed06','94927455-1bba-4e1e-a195-444b092f8f29','f35341b4-10e2-4fbd-a303-580c1455cdc9','7d5b79be-4c68-4b74-bc46-e819a952cb6b',2592000,''),('master',60,300,60,NULL,NULL,NULL,'','\0',0,NULL,'master',0,NULL,'MIIEowIBAAKCAQEAgMHsVH0DV9XVdk7tKrZGJjKLcOq+R/BN4QChTRZs/rIeLcSTaBio4jj/arzPatayFlZptA1/SuBO4pNpRYoZbbLmEqeFE8JLaq8NjMi3tTOTkhEEVPuiRBJxjFDkIELUIFKRG28UeUYxAB3IJxS4ncs6lPvXbBrrUZlc5fdpDtTiFtRBG472IdMXo1rpc+2QT8Y1vAWM5tXbon2BlotbQMcecg19Is8WTns/CGsBEZn08EYmNKajtjOOzJoeG4Y3kgxfWCuD+jyLD3H/kjghKjAMdXGn4PY1JPX3WS0fWIZK6mpVDCSlJ4QcfOS2DTzjBzyfFwd6jWPquGjn711umwIDAQABAoIBADxQGo8dHDLJ1Lsdj5UBWuzLomvbWhTCqQhrziMZDSdlciOIQHBzlLCbeHGcTiDCvxsdkVgpNmZxmiIiYR6U6QJs2b8FP54Y1lD7/QHkh8FWjprOY9QXJ1Rxu0S6I5JFG66kXpqWNuX0DkH6sWY1G6G2sBNXwPo/xdksWMrUUR8DyLHB233HwowBB409yTTL/5yW5puGR7sbUnXtNmo8OKNaZro9eSE1x0iYP8YF1JDtKCklz8HfxX54cUUtPFmD3GvyRig6mYhl5mr+qyzB5hycEaDL5TBUkYvKGsGNuKkk3ovX8HsTA9fyYuijTc1FIwpKRlvXQgS6k1p+oekDBAkCgYEAxv/bDohB3WFVmIpPcjWwlDljJoVAbHukw5fFT9syHHakwNauQCtjVo0zYhy4x8glgbhE49HQ0rZQMqihgSaxCYfhJni76Lrl/tpzbdOsypbFGsOhIaHmipiTPKFWBB4syx86KtN4P+jpIeDrlMv68F3VVG/Q5jKUSHJBf1DsX9UCgYEApaNl7Zs0V/0gem8eEyUT4NJ+nkh/73+sCBQyBDBKOCnh+JDa1hLj87zIEpJfK6EvD2xKd+8CjWBWgelCl7aUgLkMm9PyYZMd4q8EzjUELiK4+HEmOYrBsoA2rZQjCjFBcZP6zP2pi1ImcTCsTHippCVrQW3issaQKA57kBUKPK8CgYEAkNzYPm/6YonkobKtutpSvNQ51WTTTSWE/82QGV3b0NSdgrPFDXmISw1nBlkaOnT8uL3HiIDIn1uQbhBL4ZSk8+cyg6sIP5curqOfu6eH9cJjoeQffDg7d1EyfcSEtWKyAPuugFaJBx0p+TuewybqeegUz+7GB41yXHqwK1pheDECgYBuX8axIYYsx9EXpOneiguH+dxD7z3JQ0NIkuSNY/xhFo+syiH5GtdpeLe9oGnosdyhI2EwMEV8HeEnal9kp1anvCfJwt815Am7HzNNkYh6kcq+Su/U0kCmiMdmvVroFNBuNdSfOrz6yMAzFuMJhjJM3l5tWCMDTEuNVbFC3rJWowKBgFsWlteK9wC/hrjOYNA0J9jnJIzfKYU4IOlKk0E2ZjmRW6Cd5jBRxQQ4q6Yp4guXBqsxLgyrl/LMTBQOgXJCuJOwpTV/vZHAkrmsESjMtJE4hOkle6jnKQHEuxGj/KAuBaWdodb/X+345wH3FRUH6jIbmjcmP0nhBajSF+bf3Wra','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgMHsVH0DV9XVdk7tKrZGJjKLcOq+R/BN4QChTRZs/rIeLcSTaBio4jj/arzPatayFlZptA1/SuBO4pNpRYoZbbLmEqeFE8JLaq8NjMi3tTOTkhEEVPuiRBJxjFDkIELUIFKRG28UeUYxAB3IJxS4ncs6lPvXbBrrUZlc5fdpDtTiFtRBG472IdMXo1rpc+2QT8Y1vAWM5tXbon2BlotbQMcecg19Is8WTns/CGsBEZn08EYmNKajtjOOzJoeG4Y3kgxfWCuD+jyLD3H/kjghKjAMdXGn4PY1JPX3WS0fWIZK6mpVDCSlJ4QcfOS2DTzjBzyfFwd6jWPquGjn711umwIDAQAB','\0','\0','\0','\0','EXTERNAL',1800,36000,'\0','\0','dc20d618-412c-4502-93d6-e4e90d0f3e70','MIICmzCCAYMCBgFROfT/JTANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMTUxMTI0MTQ0MzU2WhcNMjUxMTI0MTQ0NTM2WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCAwexUfQNX1dV2Tu0qtkYmMotw6r5H8E3hAKFNFmz+sh4txJNoGKjiOP9qvM9q1rIWVmm0DX9K4E7ik2lFihltsuYSp4UTwktqrw2MyLe1M5OSEQRU+6JEEnGMUOQgQtQgUpEbbxR5RjEAHcgnFLidyzqU+9dsGutRmVzl92kO1OIW1EEbjvYh0xejWulz7ZBPxjW8BYzm1duifYGWi1tAxx5yDX0izxZOez8IawERmfTwRiY0pqO2M47Mmh4bhjeSDF9YK4P6PIsPcf+SOCEqMAx1cafg9jUk9fdZLR9YhkrqalUMJKUnhBx85LYNPOMHPJ8XB3qNY+q4aOfvXW6bAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAG6zrA94V4labafqxnOZ2S0SXYQXNigho3B0wSi7QWB8oE4IpGm5GGCwBKC9RtlnJVtnawIWkuWpCua1YX1P1441URxG7je1hSInE0ZT/vXILO/oX/LWCLk13AtEiIZDpFYUnf08Bv9dJC+UcbaYbVDhn6feM7zKghbeh19FQX++1RfiQpmuxYkrJq9qJfhozyTy2e2S1wsMGq4szbTufAWjYffW5EhmEuNGkrW5e5RXZx8TL0ECLf9ZCvDlgv4YYjcZ/5x/3aMat13Wma2NN9UjJEmXDeKz3TNMfjGniKQtq9pj3URQgWQHTCjRr8iDx+p+/rt7C3x+4J0EKt+AhjA=','3c89a5f0-ec0e-436a-a5b5-0298afc0bd21',1800,'\0',NULL,'\0','\0','\0','\0',0,1,30,6,'HmacSHA1','totp','40a64c43-f7d5-4fe7-a548-4fc153cab40b','c1ed2be4-bbae-4148-9d5c-61def97c3d78','f11d1afb-3632-4f97-a94a-35e7a465738f','84f3af3e-f58d-4e9e-b690-3037d4affbd4','45f48310-0eae-4b74-8584-f901694c3671',2592000,'\0');
/*!40000 ALTER TABLE `REALM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ATTRIBUTE`
--

DROP TABLE IF EXISTS `REALM_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_ATTRIBUTE` (
  `NAME` varchar(255) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`NAME`,`REALM_ID`),
  KEY `FK_8SHXD6L3E9ATQUKACXGPFFPTW` (`REALM_ID`),
  CONSTRAINT `FK_8SHXD6L3E9ATQUKACXGPFFPTW` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ATTRIBUTE`
--

LOCK TABLES `REALM_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` DISABLE KEYS */;
INSERT INTO `REALM_ATTRIBUTE` VALUES ('bruteForceProtected','false','dina'),('bruteForceProtected','false','master'),('failureFactor','30','dina'),('failureFactor','30','master'),('maxDeltaTimeSeconds','43200','dina'),('maxDeltaTimeSeconds','43200','master'),('maxFailureWaitSeconds','900','dina'),('maxFailureWaitSeconds','900','master'),('minimumQuickLoginWaitSeconds','60','dina'),('minimumQuickLoginWaitSeconds','60','master'),('quickLoginCheckMilliSeconds','1000','dina'),('quickLoginCheckMilliSeconds','1000','master'),('waitIncrementSeconds','60','dina'),('waitIncrementSeconds','60','master'),('_browser_header.contentSecurityPolicy','frame-src \'self\'','dina'),('_browser_header.contentSecurityPolicy','frame-src \'self\'','master'),('_browser_header.xFrameOptions','SAMEORIGIN','dina'),('_browser_header.xFrameOptions','SAMEORIGIN','master');
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_CLIENT`
--

DROP TABLE IF EXISTS `REALM_CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_CLIENT` (
  `REALM_ID` varchar(36) DEFAULT NULL,
  `CLIENT_ID` varchar(36) DEFAULT NULL,
  UNIQUE KEY `UK_M6QGA3RFME47335JY8JXYXH3I` (`CLIENT_ID`),
  KEY `FK_M6QGA3RFME47335JY8JXYXH3I` (`REALM_ID`),
  CONSTRAINT `FK_93S3P0DIUXAWWQQSA528UBY2Q` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`),
  CONSTRAINT `FK_M6QGA3RFME47335JY8JXYXH3I` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_CLIENT`
--

LOCK TABLES `REALM_CLIENT` WRITE;
/*!40000 ALTER TABLE `REALM_CLIENT` DISABLE KEYS */;
INSERT INTO `REALM_CLIENT` VALUES ('master','4f8273ca-19e1-47f8-acbf-ed2359a6ada0'),('master','b0276453-5047-40e9-a07d-d3da942fb21e'),('master','dc20d618-412c-4502-93d6-e4e90d0f3e70'),('master','f7b7fe46-ec29-4f68-95be-fbf3d55afc01'),('master','370b6760-428e-4b14-850b-a9bfd25fcd8c'),('dina','eb90332f-156d-4cec-8952-857232b91b3d'),('dina','12a00924-5501-4a34-a368-2be92698759c'),('dina','fe2e52fe-e34f-439e-bc4f-b1f48a1431b4'),('dina','cd875af9-7482-4bcc-a875-32d45029742f'),('dina','c72b4202-09f9-4f37-a4ca-62b3e91bcab7'),('dina','bcbb2a6e-a570-4ca5-a822-6ec5b62f5e2c'),('dina','2d57c124-63e6-4f07-977c-79167ff268f8'),('dina','5040b99e-aabf-4164-8780-0fc67c193318');
/*!40000 ALTER TABLE `REALM_CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_DEFAULT_ROLES`
--

DROP TABLE IF EXISTS `REALM_DEFAULT_ROLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_DEFAULT_ROLES` (
  `REALM_ID` varchar(36) NOT NULL,
  `ROLE_ID` varchar(36) NOT NULL,
  UNIQUE KEY `UK_H4WPD7W4HSOOLNI3H0SW7BTJE` (`ROLE_ID`),
  KEY `FK_EVUDB1PPW84OXFAX2DRS03ICC` (`REALM_ID`),
  CONSTRAINT `FK_EVUDB1PPW84OXFAX2DRS03ICC` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`),
  CONSTRAINT `FK_H4WPD7W4HSOOLNI3H0SW7BTJE` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_DEFAULT_ROLES`
--

LOCK TABLES `REALM_DEFAULT_ROLES` WRITE;
/*!40000 ALTER TABLE `REALM_DEFAULT_ROLES` DISABLE KEYS */;
INSERT INTO `REALM_DEFAULT_ROLES` VALUES ('dina','46bf6243-48ff-4205-8f31-6f0c08d08fe6'),('master','5d26f4a7-4966-4244-a8d3-bc2c8124da66');
/*!40000 ALTER TABLE `REALM_DEFAULT_ROLES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ENABLED_EVENT_TYPES`
--

DROP TABLE IF EXISTS `REALM_ENABLED_EVENT_TYPES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_ENABLED_EVENT_TYPES` (
  `REALM_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  KEY `FK_H846O4H0W8EPX5NWEDRF5Y69J` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NWEDRF5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ENABLED_EVENT_TYPES`
--

LOCK TABLES `REALM_ENABLED_EVENT_TYPES` WRITE;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_EVENTS_LISTENERS`
--

DROP TABLE IF EXISTS `REALM_EVENTS_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_EVENTS_LISTENERS` (
  `REALM_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  KEY `FK_H846O4H0W8EPX5NXEV9F5Y69J` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NXEV9F5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_EVENTS_LISTENERS`
--

LOCK TABLES `REALM_EVENTS_LISTENERS` WRITE;
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` DISABLE KEYS */;
INSERT INTO `REALM_EVENTS_LISTENERS` VALUES ('master','jboss-logging'),('dina','jboss-logging');
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_REQUIRED_CREDENTIAL`
--

DROP TABLE IF EXISTS `REALM_REQUIRED_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_REQUIRED_CREDENTIAL` (
  `TYPE` varchar(255) NOT NULL,
  `FORM_LABEL` varchar(255) DEFAULT NULL,
  `INPUT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`REALM_ID`,`TYPE`),
  CONSTRAINT `FK_5HG65LYBEVAVKQFKI3KPONH9V` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_REQUIRED_CREDENTIAL`
--

LOCK TABLES `REALM_REQUIRED_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` DISABLE KEYS */;
INSERT INTO `REALM_REQUIRED_CREDENTIAL` VALUES ('password','password','','','dina'),('password','password','','','master');
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SMTP_CONFIG`
--

DROP TABLE IF EXISTS `REALM_SMTP_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_SMTP_CONFIG` (
  `REALM_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`REALM_ID`,`NAME`),
  CONSTRAINT `FK_70EJ8XDXGXD0B9HH6180IRR0O` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SMTP_CONFIG`
--

LOCK TABLES `REALM_SMTP_CONFIG` WRITE;
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SUPPORTED_LOCALES`
--

DROP TABLE IF EXISTS `REALM_SUPPORTED_LOCALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REALM_SUPPORTED_LOCALES` (
  `REALM_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  KEY `FK_SUPPORTED_LOCALES_REALM` (`REALM_ID`),
  CONSTRAINT `FK_SUPPORTED_LOCALES_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SUPPORTED_LOCALES`
--

LOCK TABLES `REALM_SUPPORTED_LOCALES` WRITE;
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REDIRECT_URIS`
--

DROP TABLE IF EXISTS `REDIRECT_URIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REDIRECT_URIS` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  KEY `FK_1BURS8PB4OUJ97H5WUPPAHV9F` (`CLIENT_ID`),
  CONSTRAINT `FK_1BURS8PB4OUJ97H5WUPPAHV9F` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REDIRECT_URIS`
--

LOCK TABLES `REDIRECT_URIS` WRITE;
/*!40000 ALTER TABLE `REDIRECT_URIS` DISABLE KEYS */;
INSERT INTO `REDIRECT_URIS` VALUES ('f7b7fe46-ec29-4f68-95be-fbf3d55afc01','/auth/realms/master/account/*'),('b0276453-5047-40e9-a07d-d3da942fb21e','/auth/admin/master/console/*'),('12a00924-5501-4a34-a368-2be92698759c','/auth/realms/dina/account/*'),('cd875af9-7482-4bcc-a875-32d45029742f','/auth/admin/dina/console/*'),('2d57c124-63e6-4f07-977c-79167ff268f8','http://192.168.99.100:8181/test-client/*'),('5040b99e-aabf-4164-8780-0fc67c193318','https://localhost:8443/test-client/*');
/*!40000 ALTER TABLE `REDIRECT_URIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_CONFIG`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REQUIRED_ACTION_CONFIG` (
  `REQUIRED_ACTION_ID` varchar(36) NOT NULL,
  `VALUE` longtext,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`REQUIRED_ACTION_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_CONFIG`
--

LOCK TABLES `REQUIRED_ACTION_CONFIG` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_PROVIDER`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REQUIRED_ACTION_PROVIDER` (
  `ID` varchar(36) NOT NULL,
  `ALIAS` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_ACTION` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_REQ_ACT_REALM` (`REALM_ID`),
  CONSTRAINT `FK_REQ_ACT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_PROVIDER`
--

LOCK TABLES `REQUIRED_ACTION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` DISABLE KEYS */;
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('1ed84d1b-5641-4543-bf81-68e3bcefd219','UPDATE_PASSWORD','Update Password','master','','\0','UPDATE_PASSWORD'),('46d65de1-848e-4a9a-9496-ddeeb33a45af','VERIFY_EMAIL','Verify Email','master','','\0','VERIFY_EMAIL'),('5c5940cf-3706-4661-9fb5-7e39e3f112a3','terms_and_conditions','Terms and Conditions','master','\0','\0','terms_and_conditions'),('9177d26a-fb0f-4510-a9f5-c7cc74522482','CONFIGURE_TOTP','Configure Totp','dina','','\0','CONFIGURE_TOTP'),('932ad2d9-e37e-46c2-8676-fab60e8bf60a','VERIFY_EMAIL','Verify Email','dina','','\0','VERIFY_EMAIL'),('9b75d848-2d27-44a7-acdb-608282cdff8d','terms_and_conditions','Terms and Conditions','dina','\0','\0','terms_and_conditions'),('bb14f7d2-e6f3-4d82-a059-4311a6d79e38','UPDATE_PROFILE','Update Profile','master','','\0','UPDATE_PROFILE'),('e26334a4-3242-4b92-b198-0b6bd01fa929','UPDATE_PROFILE','Update Profile','dina','','\0','UPDATE_PROFILE'),('e2645dc9-f15b-41a9-a6c5-3504af4e3abc','CONFIGURE_TOTP','Configure Totp','master','','\0','CONFIGURE_TOTP'),('f7055f99-fcb3-457b-8f72-559c8d63e2b6','UPDATE_PASSWORD','Update Password','dina','','\0','UPDATE_PASSWORD');
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCOPE_MAPPING`
--

DROP TABLE IF EXISTS `SCOPE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCOPE_MAPPING` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `ROLE_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`ROLE_ID`),
  KEY `FK_P3RH9GRKU11KQFRS4FLTT7RNQ` (`ROLE_ID`),
  CONSTRAINT `FK_OUSE064PLMLR732LXJCN1Q5F1` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`),
  CONSTRAINT `FK_P3RH9GRKU11KQFRS4FLTT7RNQ` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCOPE_MAPPING`
--

LOCK TABLES `SCOPE_MAPPING` WRITE;
/*!40000 ALTER TABLE `SCOPE_MAPPING` DISABLE KEYS */;
INSERT INTO `SCOPE_MAPPING` VALUES ('cd875af9-7482-4bcc-a875-32d45029742f','5b20491e-ff7f-4b24-9ae6-58e611b8e27e'),('b0276453-5047-40e9-a07d-d3da942fb21e','f8a5df60-e37e-42ed-b538-c8be4192cc21');
/*!40000 ALTER TABLE `SCOPE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERNAME_LOGIN_FAILURE`
--

DROP TABLE IF EXISTS `USERNAME_LOGIN_FAILURE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USERNAME_LOGIN_FAILURE` (
  `REALM_ID` varchar(36) NOT NULL,
  `USERNAME` varchar(200) NOT NULL,
  `FAILED_LOGIN_NOT_BEFORE` int(11) DEFAULT NULL,
  `LAST_FAILURE` bigint(20) DEFAULT NULL,
  `LAST_IP_FAILURE` varchar(255) DEFAULT NULL,
  `NUM_FAILURES` int(11) DEFAULT NULL,
  PRIMARY KEY (`REALM_ID`,`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERNAME_LOGIN_FAILURE`
--

LOCK TABLES `USERNAME_LOGIN_FAILURE` WRITE;
/*!40000 ALTER TABLE `USERNAME_LOGIN_FAILURE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USERNAME_LOGIN_FAILURE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ATTRIBUTE`
--

DROP TABLE IF EXISTS `USER_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_ATTRIBUTE` (
  `NAME` varchar(255) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` varchar(36) NOT NULL,
  `ID` varchar(36) NOT NULL DEFAULT 'sybase-needs-something-here',
  PRIMARY KEY (`ID`),
  KEY `FK_5HRM2VLF9QL5FU043KQEPOVBR` (`USER_ID`),
  CONSTRAINT `FK_5HRM2VLF9QL5FU043KQEPOVBR` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ATTRIBUTE`
--

LOCK TABLES `USER_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `USER_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT`
--

DROP TABLE IF EXISTS `USER_CONSENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_CONSENT` (
  `ID` varchar(36) NOT NULL,
  `CLIENT_ID` varchar(36) NOT NULL,
  `USER_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_JKUWUVD56ONTGSUHOGM8UEWRT` (`CLIENT_ID`,`USER_ID`),
  KEY `FK_GRNTCSNT_USER` (`USER_ID`),
  CONSTRAINT `FK_GRNTCSNT_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT`
--

LOCK TABLES `USER_CONSENT` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT_PROT_MAPPER`
--

DROP TABLE IF EXISTS `USER_CONSENT_PROT_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_CONSENT_PROT_MAPPER` (
  `USER_CONSENT_ID` varchar(36) NOT NULL,
  `PROTOCOL_MAPPER_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`,`PROTOCOL_MAPPER_ID`),
  CONSTRAINT `FK_GRNTCSNT_PRM_GR` FOREIGN KEY (`USER_CONSENT_ID`) REFERENCES `USER_CONSENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT_PROT_MAPPER`
--

LOCK TABLES `USER_CONSENT_PROT_MAPPER` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT_PROT_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT_PROT_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT_ROLE`
--

DROP TABLE IF EXISTS `USER_CONSENT_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_CONSENT_ROLE` (
  `USER_CONSENT_ID` varchar(36) NOT NULL,
  `ROLE_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`,`ROLE_ID`),
  CONSTRAINT `FK_GRNTCSNT_ROLE_GR` FOREIGN KEY (`USER_CONSENT_ID`) REFERENCES `USER_CONSENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT_ROLE`
--

LOCK TABLES `USER_CONSENT_ROLE` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT_ROLE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ENTITY`
--

DROP TABLE IF EXISTS `USER_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_ENTITY` (
  `ID` varchar(36) NOT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `EMAIL_CONSTRAINT` varchar(255) DEFAULT NULL,
  `EMAIL_VERIFIED` bit(1) NOT NULL DEFAULT b'0',
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FEDERATION_LINK` varchar(255) DEFAULT NULL,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `TOTP` bit(1) NOT NULL DEFAULT b'0',
  `USERNAME` varchar(255) DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint(20) DEFAULT NULL,
  `SERVICE_ACCOUNT_CLIENT_LINK` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_DYKN684SL8UP1CRFEI6ECKHD7` (`REALM_ID`,`EMAIL_CONSTRAINT`),
  UNIQUE KEY `UK_RU8TT6T700S9V50BU18WS5HA6` (`REALM_ID`,`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ENTITY`
--

LOCK TABLES `USER_ENTITY` WRITE;
/*!40000 ALTER TABLE `USER_ENTITY` DISABLE KEYS */;
INSERT INTO `USER_ENTITY` VALUES ('50b55ef3-6264-4cc5-8a2f-6736337a04ce',NULL,'c4cd7134-d234-482f-9236-21e293e70c84','\0','',NULL,NULL,NULL,'dina','\0','idali',1448547176624,NULL),('ad958216-4d3e-4f50-9edd-c9c6b0640adf',NULL,'966c0093-082d-440d-bf73-b3739bb26861','\0','',NULL,'reporter','reporter','dina','\0','reporter',1448885305749,NULL),('ceea29c2-ad25-4e85-be11-ea76fc5bef17','service-account-test-client@placeholder.org','service-account-test-client@placeholder.org','\0','',NULL,NULL,NULL,'dina','\0','service-account-test-client',1448633127821,'2d57c124-63e6-4f07-977c-79167ff268f8'),('fb600f3d-8a1d-4368-8fe1-239f56af7788',NULL,'41b7b75d-2908-4a96-80cf-418504b4eae7','\0','',NULL,NULL,NULL,'master','\0','admin',1448376336300,NULL);
/*!40000 ALTER TABLE `USER_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_FEDERATION_CONFIG` (
  `USER_FEDERATION_PROVIDER_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FK_T13HPU1J94R2EBPEKR39X5EU5` FOREIGN KEY (`USER_FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_CONFIG`
--

LOCK TABLES `USER_FEDERATION_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_FEDERATION_MAPPER` (
  `ID` varchar(36) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `FEDERATION_PROVIDER_ID` varchar(36) NOT NULL,
  `FEDERATION_MAPPER_TYPE` varchar(255) NOT NULL,
  `REALM_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_FEDMAPPERPM_REALM` (`REALM_ID`),
  KEY `FK_FEDMAPPERPM_FEDPRV` (`FEDERATION_PROVIDER_ID`),
  CONSTRAINT `FK_FEDMAPPERPM_FEDPRV` FOREIGN KEY (`FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`),
  CONSTRAINT `FK_FEDMAPPERPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER`
--

LOCK TABLES `USER_FEDERATION_MAPPER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_FEDERATION_MAPPER_CONFIG` (
  `USER_FEDERATION_MAPPER_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_FEDMAPPER_CFG` FOREIGN KEY (`USER_FEDERATION_MAPPER_ID`) REFERENCES `USER_FEDERATION_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER_CONFIG`
--

LOCK TABLES `USER_FEDERATION_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_PROVIDER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_FEDERATION_PROVIDER` (
  `ID` varchar(36) NOT NULL,
  `CHANGED_SYNC_PERIOD` int(11) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  `FULL_SYNC_PERIOD` int(11) DEFAULT NULL,
  `LAST_SYNC` int(11) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `PROVIDER_NAME` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_1FJ32F6PTOLW2QY60CD8N01E8` (`REALM_ID`),
  CONSTRAINT `FK_1FJ32F6PTOLW2QY60CD8N01E8` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_PROVIDER`
--

LOCK TABLES `USER_FEDERATION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_REQUIRED_ACTION`
--

DROP TABLE IF EXISTS `USER_REQUIRED_ACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_REQUIRED_ACTION` (
  `USER_ID` varchar(36) NOT NULL,
  `REQUIRED_ACTION` varchar(255) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`REQUIRED_ACTION`,`USER_ID`),
  KEY `FK_6QJ3W1JW9CVAFHE19BWSIUVMD` (`USER_ID`),
  CONSTRAINT `FK_6QJ3W1JW9CVAFHE19BWSIUVMD` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_REQUIRED_ACTION`
--

LOCK TABLES `USER_REQUIRED_ACTION` WRITE;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `USER_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_ROLE_MAPPING` (
  `ROLE_ID` varchar(255) NOT NULL,
  `USER_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `FK_C4FQV34P1MBYLLOXANG7B1Q3L` (`USER_ID`),
  CONSTRAINT `FK_C4FQV34P1MBYLLOXANG7B1Q3L` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ROLE_MAPPING`
--

LOCK TABLES `USER_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `USER_ROLE_MAPPING` VALUES ('12477919-cb52-49a4-91d1-c8216ad4bf2e','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('2ed48f4b-45f9-48df-baf9-f996f1970b42','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('3981c710-535b-4c3d-a895-75d6f1328c54','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('43dc4719-7482-4f38-a4e5-7f57d9534e81','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('46bf6243-48ff-4205-8f31-6f0c08d08fe6','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('50fa9e38-361a-47e6-b7f3-db92daf750be','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('689c6c31-ed5e-4f8c-8898-d1d9107834fd','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('750a49ad-d013-4999-970b-7a322e63b203','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('89ffb599-3910-4588-b155-8e8518682175','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('99b83880-32ee-4ffe-827c-0bfdd9acb303','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('cf014c94-719d-49a8-8f65-fb931bba7691','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('d646f695-1652-431a-bf99-bf422e5147e0','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('df94a3b9-9f58-47ae-9f60-834ce86f46be','50b55ef3-6264-4cc5-8a2f-6736337a04ce'),('12477919-cb52-49a4-91d1-c8216ad4bf2e','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('3981c710-535b-4c3d-a895-75d6f1328c54','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('43dc4719-7482-4f38-a4e5-7f57d9534e81','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('46bf6243-48ff-4205-8f31-6f0c08d08fe6','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('50fa9e38-361a-47e6-b7f3-db92daf750be','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('689c6c31-ed5e-4f8c-8898-d1d9107834fd','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('750a49ad-d013-4999-970b-7a322e63b203','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('89ffb599-3910-4588-b155-8e8518682175','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('99b83880-32ee-4ffe-827c-0bfdd9acb303','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('cf014c94-719d-49a8-8f65-fb931bba7691','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('df94a3b9-9f58-47ae-9f60-834ce86f46be','ad958216-4d3e-4f50-9edd-c9c6b0640adf'),('46bf6243-48ff-4205-8f31-6f0c08d08fe6','ceea29c2-ad25-4e85-be11-ea76fc5bef17'),('89ffb599-3910-4588-b155-8e8518682175','ceea29c2-ad25-4e85-be11-ea76fc5bef17'),('99b83880-32ee-4ffe-827c-0bfdd9acb303','ceea29c2-ad25-4e85-be11-ea76fc5bef17'),('5d26f4a7-4966-4244-a8d3-bc2c8124da66','fb600f3d-8a1d-4368-8fe1-239f56af7788'),('b9640b04-5396-439f-8e4b-7bffff950f59','fb600f3d-8a1d-4368-8fe1-239f56af7788'),('d8eec9a7-a05d-48d9-93ef-a82293979dec','fb600f3d-8a1d-4368-8fe1-239f56af7788'),('f8a5df60-e37e-42ed-b538-c8be4192cc21','fb600f3d-8a1d-4368-8fe1-239f56af7788');
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_SESSION`
--

DROP TABLE IF EXISTS `USER_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_SESSION` (
  `ID` varchar(36) NOT NULL,
  `AUTH_METHOD` varchar(255) DEFAULT NULL,
  `IP_ADDRESS` varchar(255) DEFAULT NULL,
  `LAST_SESSION_REFRESH` int(11) DEFAULT NULL,
  `LOGIN_USERNAME` varchar(255) DEFAULT NULL,
  `REALM_ID` varchar(255) DEFAULT NULL,
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `STARTED` int(11) DEFAULT NULL,
  `USER_ID` varchar(255) DEFAULT NULL,
  `USER_SESSION_STATE` int(11) DEFAULT NULL,
  `BROKER_SESSION_ID` varchar(255) DEFAULT NULL,
  `BROKER_USER_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_SESSION`
--

LOCK TABLES `USER_SESSION` WRITE;
/*!40000 ALTER TABLE `USER_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_SESSION_NOTE`
--

DROP TABLE IF EXISTS `USER_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_SESSION_NOTE` (
  `USER_SESSION` varchar(36) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `VALUE` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`USER_SESSION`,`NAME`),
  CONSTRAINT `FK5EDFB00FF51D3472` FOREIGN KEY (`USER_SESSION`) REFERENCES `USER_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_SESSION_NOTE`
--

LOCK TABLES `USER_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `USER_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_ORIGINS`
--

DROP TABLE IF EXISTS `WEB_ORIGINS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WEB_ORIGINS` (
  `CLIENT_ID` varchar(36) NOT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  KEY `FK_LOJPHO213XCX4WNKOG82SSRFY` (`CLIENT_ID`),
  CONSTRAINT `FK_LOJPHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_ORIGINS`
--

LOCK TABLES `WEB_ORIGINS` WRITE;
/*!40000 ALTER TABLE `WEB_ORIGINS` DISABLE KEYS */;
/*!40000 ALTER TABLE `WEB_ORIGINS` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-30 16:35:55
